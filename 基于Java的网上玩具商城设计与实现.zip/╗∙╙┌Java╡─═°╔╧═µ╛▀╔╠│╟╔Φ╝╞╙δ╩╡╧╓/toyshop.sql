/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50540
Source Host           : localhost:3306
Source Database       : toyshop

Target Server Type    : MYSQL
Target Server Version : 50540
File Encoding         : 65001

Date: 2020-05-29 18:48:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `address`
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `address` varchar(255) DEFAULT NULL COMMENT '详细地址',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `zipcode` int(11) DEFAULT NULL COMMENT '邮政编码',
  `username` varchar(255) DEFAULT NULL COMMENT '收件人姓名',
  `bz1` int(11) DEFAULT NULL,
  `bz2` int(11) DEFAULT NULL,
  `bz3` varchar(255) DEFAULT NULL,
  `bz4` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of address
-- ----------------------------

-- ----------------------------
-- Table structure for `evaluate`
-- ----------------------------
DROP TABLE IF EXISTS `evaluate`;
CREATE TABLE `evaluate` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `toyid` int(11) DEFAULT NULL COMMENT '商品id',
  `toynoid` varchar(255) DEFAULT NULL COMMENT '订单号',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `evaluate` text COMMENT '评价',
  `scoring` int(11) DEFAULT NULL COMMENT '打分',
  `bz1` int(11) DEFAULT NULL,
  `bz2` int(11) DEFAULT NULL,
  `bz3` varchar(255) DEFAULT NULL,
  `bz4` varchar(255) DEFAULT NULL,
  `bz5` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of evaluate
-- ----------------------------
INSERT INTO `evaluate` VALUES ('48', '68', '1589440818656', '50', '123', '4', null, null, null, null, null);

-- ----------------------------
-- Table structure for `loginlog`
-- ----------------------------
DROP TABLE IF EXISTS `loginlog`;
CREATE TABLE `loginlog` (
  `loginid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `loginip` varchar(255) DEFAULT NULL,
  `logintime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`loginid`)
) ENGINE=InnoDB AUTO_INCREMENT=883 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of loginlog
-- ----------------------------
INSERT INTO `loginlog` VALUES ('653', null, 'admin', '127.0.0.1', '2020-04-03 18:53:16');
INSERT INTO `loginlog` VALUES ('654', null, 'ls', '127.0.0.1', '2020-04-04 13:19:20');
INSERT INTO `loginlog` VALUES ('655', null, 'lss', '127.0.0.1', '2020-04-04 13:20:32');
INSERT INTO `loginlog` VALUES ('664', null, 'admin', '127.0.0.1', '2020-04-04 13:32:05');
INSERT INTO `loginlog` VALUES ('665', null, 'admin', '127.0.0.1', '2020-04-04 17:21:48');
INSERT INTO `loginlog` VALUES ('666', null, 'admin', '127.0.0.1', '2020-04-04 17:39:11');
INSERT INTO `loginlog` VALUES ('667', null, 'admin', '127.0.0.1', '2020-04-04 18:00:22');
INSERT INTO `loginlog` VALUES ('668', null, 'admin', '127.0.0.1', '2020-04-04 18:04:12');
INSERT INTO `loginlog` VALUES ('669', null, 'ls', '127.0.0.1', '2020-04-04 21:42:02');
INSERT INTO `loginlog` VALUES ('670', null, 'ls', '127.0.0.1', '2020-04-04 21:42:05');
INSERT INTO `loginlog` VALUES ('684', null, 'ls', '127.0.0.1', '2020-04-04 21:43:36');
INSERT INTO `loginlog` VALUES ('685', null, 'ltt', '127.0.0.1', '2020-04-04 21:49:25');
INSERT INTO `loginlog` VALUES ('686', null, 'admin', '127.0.0.1', '2020-04-04 21:50:15');
INSERT INTO `loginlog` VALUES ('687', null, 'admin', '127.0.0.1', '2020-04-04 22:07:39');
INSERT INTO `loginlog` VALUES ('688', null, 'ls', '127.0.0.1', '2020-04-04 22:10:30');
INSERT INTO `loginlog` VALUES ('689', null, 'lt', '127.0.0.1', '2020-04-04 22:10:51');
INSERT INTO `loginlog` VALUES ('690', null, '搜索', '127.0.0.1', '2020-04-04 22:14:17');
INSERT INTO `loginlog` VALUES ('691', null, 'admin', '127.0.0.1', '2020-04-04 22:14:36');
INSERT INTO `loginlog` VALUES ('692', null, 'admin', '127.0.0.1', '2020-04-04 22:31:48');
INSERT INTO `loginlog` VALUES ('693', null, 'lss', '127.0.0.1', '2020-04-04 22:33:50');
INSERT INTO `loginlog` VALUES ('694', null, 'lsss', '127.0.0.1', '2020-04-04 22:34:19');
INSERT INTO `loginlog` VALUES ('695', null, 'admin', '127.0.0.1', '2020-04-05 11:01:22');
INSERT INTO `loginlog` VALUES ('696', null, 'szj', '127.0.0.1', '2020-04-13 13:42:14');
INSERT INTO `loginlog` VALUES ('697', null, 'admin', '127.0.0.1', '2020-04-14 13:32:24');
INSERT INTO `loginlog` VALUES ('698', null, 'JiaF', '127.0.0.1', '2020-04-14 13:33:21');
INSERT INTO `loginlog` VALUES ('699', null, 'JiaF', '127.0.0.1', '2020-04-14 13:34:28');
INSERT INTO `loginlog` VALUES ('700', null, 'admin', '127.0.0.1', '2020-04-14 13:38:37');
INSERT INTO `loginlog` VALUES ('701', null, 'JiaF', '127.0.0.1', '2020-04-14 13:42:31');
INSERT INTO `loginlog` VALUES ('702', null, 'zhz', '127.0.0.1', '2020-04-14 17:30:37');
INSERT INTO `loginlog` VALUES ('703', null, 'zhz', '127.0.0.1', '2020-04-14 18:49:02');
INSERT INTO `loginlog` VALUES ('704', null, 'zhz', '127.0.0.1', '2020-04-14 18:53:43');
INSERT INTO `loginlog` VALUES ('705', null, 'admin', '127.0.0.1', '2020-04-15 11:03:41');
INSERT INTO `loginlog` VALUES ('706', null, 'ls', '127.0.0.1', '2020-04-15 11:25:11');
INSERT INTO `loginlog` VALUES ('707', null, ' tt', '127.0.0.1', '2020-04-15 11:40:56');
INSERT INTO `loginlog` VALUES ('708', null, ' tt', '127.0.0.1', '2020-04-15 11:40:59');
INSERT INTO `loginlog` VALUES ('709', null, 'ttt', '127.0.0.1', '2020-04-15 11:41:11');
INSERT INTO `loginlog` VALUES ('710', null, 'ttt', '127.0.0.1', '2020-04-15 11:41:36');
INSERT INTO `loginlog` VALUES ('711', null, 'qs', '127.0.0.1', '2020-04-18 09:42:26');
INSERT INTO `loginlog` VALUES ('712', null, 'admin', '127.0.0.1', '2020-04-18 09:50:10');
INSERT INTO `loginlog` VALUES ('713', null, 'qs', '127.0.0.1', '2020-04-18 09:50:35');
INSERT INTO `loginlog` VALUES ('714', null, 'qs', '127.0.0.1', '2020-04-18 09:58:01');
INSERT INTO `loginlog` VALUES ('715', null, 'admin', '127.0.0.1', '2020-04-18 10:18:15');
INSERT INTO `loginlog` VALUES ('716', null, 'qs', '127.0.0.1', '2020-04-18 10:18:32');
INSERT INTO `loginlog` VALUES ('717', null, 'qs', '127.0.0.1', '2020-04-18 10:22:54');
INSERT INTO `loginlog` VALUES ('718', null, 'admin', '127.0.0.1', '2020-04-20 21:00:03');
INSERT INTO `loginlog` VALUES ('719', null, 'admin', '127.0.0.1', '2020-04-21 12:53:48');
INSERT INTO `loginlog` VALUES ('720', null, 'admin', '127.0.0.1', '2020-04-21 12:56:29');
INSERT INTO `loginlog` VALUES ('721', null, 'admin', '127.0.0.1', '2020-04-22 17:03:30');
INSERT INTO `loginlog` VALUES ('722', null, 'admin', '127.0.0.1', '2020-04-22 17:11:15');
INSERT INTO `loginlog` VALUES ('723', null, 'admin', '127.0.0.1', '2020-04-24 11:41:55');
INSERT INTO `loginlog` VALUES ('724', null, 'admin', '127.0.0.1', '2020-04-24 13:11:40');
INSERT INTO `loginlog` VALUES ('725', null, 'admin', '127.0.0.1', '2020-04-24 14:01:58');
INSERT INTO `loginlog` VALUES ('726', null, 'admin', '127.0.0.1', '2020-04-24 14:02:50');
INSERT INTO `loginlog` VALUES ('727', null, 'admin', '127.0.0.1', '2020-04-24 15:03:08');
INSERT INTO `loginlog` VALUES ('728', null, 'admin', '127.0.0.1', '2020-04-24 15:22:49');
INSERT INTO `loginlog` VALUES ('729', null, 'admin', '127.0.0.1', '2020-04-24 15:26:47');
INSERT INTO `loginlog` VALUES ('730', null, 'admin', '127.0.0.1', '2020-04-24 15:34:40');
INSERT INTO `loginlog` VALUES ('731', null, 'admin', '127.0.0.1', '2020-04-24 15:41:52');
INSERT INTO `loginlog` VALUES ('732', null, 'admin', '127.0.0.1', '2020-04-24 15:58:21');
INSERT INTO `loginlog` VALUES ('733', null, 'admin', '127.0.0.1', '2020-04-24 16:07:41');
INSERT INTO `loginlog` VALUES ('734', null, 'admin', '127.0.0.1', '2020-04-24 16:10:28');
INSERT INTO `loginlog` VALUES ('735', null, 'admin', '127.0.0.1', '2020-04-24 16:11:48');
INSERT INTO `loginlog` VALUES ('736', null, 'admin', '127.0.0.1', '2020-04-24 16:13:03');
INSERT INTO `loginlog` VALUES ('737', null, 'ls', '127.0.0.1', '2020-04-24 16:39:33');
INSERT INTO `loginlog` VALUES ('738', null, 'ls', '127.0.0.1', '2020-04-24 16:47:17');
INSERT INTO `loginlog` VALUES ('739', null, 'ls', '127.0.0.1', '2020-04-24 16:48:14');
INSERT INTO `loginlog` VALUES ('740', null, 'ls', '127.0.0.1', '2020-04-24 16:56:54');
INSERT INTO `loginlog` VALUES ('741', null, 'ls', '127.0.0.1', '2020-04-24 16:58:22');
INSERT INTO `loginlog` VALUES ('742', null, 'admin', '127.0.0.1', '2020-04-24 17:10:32');
INSERT INTO `loginlog` VALUES ('743', null, 'ls', '127.0.0.1', '2020-04-24 17:10:49');
INSERT INTO `loginlog` VALUES ('744', null, 'admin', '127.0.0.1', '2020-04-24 19:26:05');
INSERT INTO `loginlog` VALUES ('745', null, 'admin', '127.0.0.1', '2020-04-24 19:29:22');
INSERT INTO `loginlog` VALUES ('746', null, 'ls', '127.0.0.1', '2020-04-24 19:29:36');
INSERT INTO `loginlog` VALUES ('747', null, 'ls', '127.0.0.1', '2020-04-26 13:59:43');
INSERT INTO `loginlog` VALUES ('748', null, 'admin', '127.0.0.1', '2020-04-26 14:01:15');
INSERT INTO `loginlog` VALUES ('749', null, 'ls', '127.0.0.1', '2020-04-26 14:01:49');
INSERT INTO `loginlog` VALUES ('750', null, 'ls', '127.0.0.1', '2020-04-26 14:02:37');
INSERT INTO `loginlog` VALUES ('751', null, 'ls', '127.0.0.1', '2020-04-26 14:07:24');
INSERT INTO `loginlog` VALUES ('752', null, 'ls', '127.0.0.1', '2020-04-26 14:15:53');
INSERT INTO `loginlog` VALUES ('753', null, 'ls', '127.0.0.1', '2020-04-26 14:16:28');
INSERT INTO `loginlog` VALUES ('754', null, 'admin', '127.0.0.1', '2020-04-26 14:19:32');
INSERT INTO `loginlog` VALUES ('755', null, 'ls', '127.0.0.1', '2020-04-26 14:20:06');
INSERT INTO `loginlog` VALUES ('756', null, 'ls', '127.0.0.1', '2020-04-26 14:28:04');
INSERT INTO `loginlog` VALUES ('757', null, 'admin', '127.0.0.1', '2020-04-26 14:33:09');
INSERT INTO `loginlog` VALUES ('758', null, 'admin', '127.0.0.1', '2020-04-28 19:03:31');
INSERT INTO `loginlog` VALUES ('759', null, 'ls', '127.0.0.1', '2020-04-28 19:18:13');
INSERT INTO `loginlog` VALUES ('760', null, 'admin', '127.0.0.1', '2020-04-28 19:48:21');
INSERT INTO `loginlog` VALUES ('761', null, 'admin', '127.0.0.1', '2020-04-29 13:27:44');
INSERT INTO `loginlog` VALUES ('762', null, 'ls', '127.0.0.1', '2020-04-29 14:15:05');
INSERT INTO `loginlog` VALUES ('763', null, 'admin', '127.0.0.1', '2020-04-29 14:15:54');
INSERT INTO `loginlog` VALUES ('764', null, 'admin', '127.0.0.1', '2020-04-29 14:25:04');
INSERT INTO `loginlog` VALUES ('765', null, 'admin', '127.0.0.1', '2020-04-29 14:26:07');
INSERT INTO `loginlog` VALUES ('766', null, 'admin', '127.0.0.1', '2020-04-29 19:33:56');
INSERT INTO `loginlog` VALUES ('767', null, 'admin', '127.0.0.1', '2020-04-29 19:53:38');
INSERT INTO `loginlog` VALUES ('768', null, 'admin', '127.0.0.1', '2020-04-29 20:12:25');
INSERT INTO `loginlog` VALUES ('769', null, 'admin', '127.0.0.1', '2020-04-29 20:13:17');
INSERT INTO `loginlog` VALUES ('770', null, 'admin', '127.0.0.1', '2020-04-29 20:29:43');
INSERT INTO `loginlog` VALUES ('771', null, 'ls', '127.0.0.1', '2020-04-29 21:07:30');
INSERT INTO `loginlog` VALUES ('772', null, 'ls', '127.0.0.1', '2020-04-29 21:11:59');
INSERT INTO `loginlog` VALUES ('773', null, '李赛', '127.0.0.1', '2020-04-29 21:13:20');
INSERT INTO `loginlog` VALUES ('774', null, '李赛', '127.0.0.1', '2020-04-29 21:14:34');
INSERT INTO `loginlog` VALUES ('775', null, 'admin', '127.0.0.1', '2020-04-29 21:15:01');
INSERT INTO `loginlog` VALUES ('776', null, 'ls', '127.0.0.1', '2020-04-29 21:18:00');
INSERT INTO `loginlog` VALUES ('777', null, 'admin', '127.0.0.1', '2020-04-29 21:24:34');
INSERT INTO `loginlog` VALUES ('778', null, 'ls', '127.0.0.1', '2020-04-29 21:25:05');
INSERT INTO `loginlog` VALUES ('779', null, 'ls', '127.0.0.1', '2020-04-29 21:33:22');
INSERT INTO `loginlog` VALUES ('780', null, 'ls', '127.0.0.1', '2020-04-29 21:58:23');
INSERT INTO `loginlog` VALUES ('781', null, 'admin', '127.0.0.1', '2020-04-29 21:59:54');
INSERT INTO `loginlog` VALUES ('782', null, 'admin', '127.0.0.1', '2020-04-30 17:01:51');
INSERT INTO `loginlog` VALUES ('783', null, 'admin', '127.0.0.1', '2020-04-30 17:08:56');
INSERT INTO `loginlog` VALUES ('784', null, 'ls', '127.0.0.1', '2020-04-30 18:22:33');
INSERT INTO `loginlog` VALUES ('785', null, 'admin', '127.0.0.1', '2020-04-30 18:26:58');
INSERT INTO `loginlog` VALUES ('786', null, 'ls', '127.0.0.1', '2020-04-30 18:27:49');
INSERT INTO `loginlog` VALUES ('787', null, 'admin', '127.0.0.1', '2020-04-30 18:53:05');
INSERT INTO `loginlog` VALUES ('788', null, 'admin', '127.0.0.1', '2020-04-30 19:29:29');
INSERT INTO `loginlog` VALUES ('789', null, 'ls', '127.0.0.1', '2020-04-30 19:43:14');
INSERT INTO `loginlog` VALUES ('790', null, 'test', '127.0.0.1', '2020-04-30 20:45:00');
INSERT INTO `loginlog` VALUES ('791', null, 'test', '127.0.0.1', '2020-04-30 20:45:05');
INSERT INTO `loginlog` VALUES ('792', null, 'admin', '127.0.0.1', '2020-04-30 20:50:20');
INSERT INTO `loginlog` VALUES ('793', null, 'test', '127.0.0.1', '2020-04-30 20:53:56');
INSERT INTO `loginlog` VALUES ('794', null, 'test', '修改密码校验', '2020-04-30 20:55:02');
INSERT INTO `loginlog` VALUES ('795', null, 'test', '127.0.0.1', '2020-04-30 20:55:12');
INSERT INTO `loginlog` VALUES ('796', null, 'admin', '127.0.0.1', '2020-05-07 12:32:29');
INSERT INTO `loginlog` VALUES ('797', null, 'ls', '127.0.0.1', '2020-05-09 14:42:33');
INSERT INTO `loginlog` VALUES ('798', null, 'ls', '127.0.0.1', '2020-05-09 15:16:43');
INSERT INTO `loginlog` VALUES ('799', null, 'ls', '127.0.0.1', '2020-05-09 15:35:10');
INSERT INTO `loginlog` VALUES ('800', null, 'ls', '127.0.0.1', '2020-05-09 15:40:18');
INSERT INTO `loginlog` VALUES ('801', null, 'admin', '127.0.0.1', '2020-05-09 15:42:50');
INSERT INTO `loginlog` VALUES ('802', null, 'ls', '127.0.0.1', '2020-05-09 15:43:13');
INSERT INTO `loginlog` VALUES ('803', null, 'ls', '127.0.0.1', '2020-05-14 14:40:34');
INSERT INTO `loginlog` VALUES ('804', null, 'ls', '127.0.0.1', '2020-05-14 14:47:33');
INSERT INTO `loginlog` VALUES ('805', null, 'admin', '127.0.0.1', '2020-05-14 14:53:31');
INSERT INTO `loginlog` VALUES ('806', null, 'ls', '127.0.0.1', '2020-05-14 14:57:00');
INSERT INTO `loginlog` VALUES ('807', null, 'ls', '127.0.0.1', '2020-05-14 15:07:44');
INSERT INTO `loginlog` VALUES ('808', null, 'ls', '127.0.0.1', '2020-05-14 15:31:51');
INSERT INTO `loginlog` VALUES ('809', null, 'ls', '127.0.0.1', '2020-05-14 15:31:55');
INSERT INTO `loginlog` VALUES ('810', null, 'ls', '127.0.0.1', '2020-05-14 23:46:36');
INSERT INTO `loginlog` VALUES ('811', null, 'ls', '127.0.0.1', '2020-05-15 09:53:23');
INSERT INTO `loginlog` VALUES ('812', null, 'ls', '127.0.0.1', '2020-05-15 09:54:09');
INSERT INTO `loginlog` VALUES ('813', null, 'test2', '127.0.0.1', '2020-05-19 10:49:23');
INSERT INTO `loginlog` VALUES ('814', null, 'admin', '127.0.0.1', '2020-05-19 10:54:20');
INSERT INTO `loginlog` VALUES ('815', null, 'admin', '127.0.0.1', '2020-05-19 10:58:08');
INSERT INTO `loginlog` VALUES ('816', null, 'admin', '127.0.0.1', '2020-05-19 10:58:42');
INSERT INTO `loginlog` VALUES ('817', null, 'admin', '127.0.0.1', '2020-05-19 11:01:17');
INSERT INTO `loginlog` VALUES ('818', null, 'admin', '127.0.0.1', '2020-05-19 11:02:00');
INSERT INTO `loginlog` VALUES ('819', null, 'admin', '127.0.0.1', '2020-05-19 11:04:20');
INSERT INTO `loginlog` VALUES ('820', null, 'test', '127.0.0.1', '2020-05-19 11:06:50');
INSERT INTO `loginlog` VALUES ('821', null, 'test', '127.0.0.1', '2020-05-19 11:07:29');
INSERT INTO `loginlog` VALUES ('822', null, 'test', '127.0.0.1', '2020-05-19 11:07:36');
INSERT INTO `loginlog` VALUES ('823', null, 'admin', '127.0.0.1', '2020-05-19 11:12:34');
INSERT INTO `loginlog` VALUES ('824', null, 'test', '127.0.0.1', '2020-05-19 11:16:03');
INSERT INTO `loginlog` VALUES ('825', null, 'admin', '127.0.0.1', '2020-05-19 11:21:01');
INSERT INTO `loginlog` VALUES ('826', null, 'test3', '127.0.0.1', '2020-05-19 13:40:14');
INSERT INTO `loginlog` VALUES ('827', null, 'admin', '127.0.0.1', '2020-05-19 13:40:48');
INSERT INTO `loginlog` VALUES ('828', null, 'test', '127.0.0.1', '2020-05-19 13:44:32');
INSERT INTO `loginlog` VALUES ('829', null, 'test', '修改密码校验', '2020-05-19 13:45:09');
INSERT INTO `loginlog` VALUES ('830', null, 'test', '127.0.0.1', '2020-05-19 13:45:26');
INSERT INTO `loginlog` VALUES ('831', null, 'test', '127.0.0.1', '2020-05-19 13:45:29');
INSERT INTO `loginlog` VALUES ('832', null, 'admin', '127.0.0.1', '2020-05-19 13:47:15');
INSERT INTO `loginlog` VALUES ('833', null, 'test', '127.0.0.1', '2020-05-19 13:50:39');
INSERT INTO `loginlog` VALUES ('834', null, 'admin', '127.0.0.1', '2020-05-19 13:55:12');
INSERT INTO `loginlog` VALUES ('835', null, 'admin', '127.0.0.1', '2020-05-19 14:01:07');
INSERT INTO `loginlog` VALUES ('836', null, 'test', '127.0.0.1', '2020-05-19 14:05:43');
INSERT INTO `loginlog` VALUES ('837', null, 'test', '修改密码校验', '2020-05-19 14:07:21');
INSERT INTO `loginlog` VALUES ('838', null, 'test', '127.0.0.1', '2020-05-19 14:07:36');
INSERT INTO `loginlog` VALUES ('839', null, 'admin', '127.0.0.1', '2020-05-19 14:11:00');
INSERT INTO `loginlog` VALUES ('840', null, 'admin', '127.0.0.1', '2020-05-19 14:14:14');
INSERT INTO `loginlog` VALUES ('841', null, 'test', '127.0.0.1', '2020-05-19 14:19:05');
INSERT INTO `loginlog` VALUES ('842', null, 'test', '修改密码校验', '2020-05-19 14:21:22');
INSERT INTO `loginlog` VALUES ('843', null, 'test', '127.0.0.1', '2020-05-19 14:21:29');
INSERT INTO `loginlog` VALUES ('844', null, 'admin', '127.0.0.1', '2020-05-19 14:24:09');
INSERT INTO `loginlog` VALUES ('845', null, 'test', '127.0.0.1', '2020-05-19 14:28:11');
INSERT INTO `loginlog` VALUES ('846', null, 'admin', '127.0.0.1', '2020-05-19 14:29:22');
INSERT INTO `loginlog` VALUES ('847', null, 'test', '127.0.0.1', '2020-05-19 14:29:50');
INSERT INTO `loginlog` VALUES ('848', null, 'admin', '127.0.0.1', '2020-05-19 14:48:22');
INSERT INTO `loginlog` VALUES ('849', null, 'test', '127.0.0.1', '2020-05-19 14:48:49');
INSERT INTO `loginlog` VALUES ('850', null, 'admin', '127.0.0.1', '2020-05-19 14:49:24');
INSERT INTO `loginlog` VALUES ('851', null, 'ls', '127.0.0.1', '2020-05-19 22:34:45');
INSERT INTO `loginlog` VALUES ('852', null, 'admin', '127.0.0.1', '2020-05-21 13:10:34');
INSERT INTO `loginlog` VALUES ('853', null, 'admin', '127.0.0.1', '2020-05-21 13:11:18');
INSERT INTO `loginlog` VALUES ('854', null, 'ls', '127.0.0.1', '2020-05-21 13:11:49');
INSERT INTO `loginlog` VALUES ('855', null, 'admin', '127.0.0.1', '2020-05-21 13:12:13');
INSERT INTO `loginlog` VALUES ('856', null, 'ls', '127.0.0.1', '2020-05-21 13:12:39');
INSERT INTO `loginlog` VALUES ('857', null, 'admin', '127.0.0.1', '2020-05-21 13:13:31');
INSERT INTO `loginlog` VALUES ('858', null, 'ls', '127.0.0.1', '2020-05-21 13:13:54');
INSERT INTO `loginlog` VALUES ('859', null, 'ls', '127.0.0.1', '2020-05-21 13:15:14');
INSERT INTO `loginlog` VALUES ('860', null, 'ls', '127.0.0.1', '2020-05-21 13:30:02');
INSERT INTO `loginlog` VALUES ('861', null, 'ls', '127.0.0.1', '2020-05-21 13:30:38');
INSERT INTO `loginlog` VALUES ('862', null, 'ls', '127.0.0.1', '2020-05-22 12:28:40');
INSERT INTO `loginlog` VALUES ('863', null, 'admin', '127.0.0.1', '2020-05-22 18:26:02');
INSERT INTO `loginlog` VALUES ('864', null, '测试头像', '127.0.0.1', '2020-05-22 18:26:52');
INSERT INTO `loginlog` VALUES ('865', null, 'admin', '127.0.0.1', '2020-05-22 18:34:48');
INSERT INTO `loginlog` VALUES ('866', null, 'admin', '127.0.0.1', '2020-05-22 18:36:08');
INSERT INTO `loginlog` VALUES ('867', null, 'admin', '127.0.0.1', '2020-05-22 18:38:49');
INSERT INTO `loginlog` VALUES ('868', null, 'admin', '127.0.0.1', '2020-05-22 18:39:50');
INSERT INTO `loginlog` VALUES ('869', null, 'tx3', '127.0.0.1', '2020-05-22 18:40:26');
INSERT INTO `loginlog` VALUES ('870', null, 'admin', '127.0.0.1', '2020-05-22 18:45:13');
INSERT INTO `loginlog` VALUES ('871', null, 'ls', '127.0.0.1', '2020-05-23 08:02:22');
INSERT INTO `loginlog` VALUES ('872', null, 'admin', '127.0.0.1', '2020-05-23 08:03:33');
INSERT INTO `loginlog` VALUES ('873', null, 'ls', '127.0.0.1', '2020-05-23 08:04:01');
INSERT INTO `loginlog` VALUES ('874', null, 'lisa', '127.0.0.1', '2020-05-23 08:05:18');
INSERT INTO `loginlog` VALUES ('875', null, 'lisai', '127.0.0.1', '2020-05-23 08:05:28');
INSERT INTO `loginlog` VALUES ('876', null, 'test', '127.0.0.1', '2020-05-23 11:45:04');
INSERT INTO `loginlog` VALUES ('877', null, 'ls', '127.0.0.1', '2020-05-23 11:50:10');
INSERT INTO `loginlog` VALUES ('878', null, 'admin', '127.0.0.1', '2020-05-23 11:50:41');
INSERT INTO `loginlog` VALUES ('879', null, 'ls', '127.0.0.1', '2020-05-23 11:55:22');
INSERT INTO `loginlog` VALUES ('880', null, 'admin', '127.0.0.1', '2020-05-23 11:56:38');
INSERT INTO `loginlog` VALUES ('881', null, 'ls', '127.0.0.1', '2020-05-23 11:57:01');
INSERT INTO `loginlog` VALUES ('882', null, 'admin', '127.0.0.1', '2020-05-24 11:29:31');

-- ----------------------------
-- Table structure for `menu`
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `menuId` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `parentid` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`menuId`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('2', '主页', '1', '');
INSERT INTO `menu` VALUES ('3', '主页信息', '2', 'mainlist');
INSERT INTO `menu` VALUES ('4', '商品管理', '1', '');
INSERT INTO `menu` VALUES ('5', '商品列表', '4', 'findToyHandler');
INSERT INTO `menu` VALUES ('6', '商品添加', '4', 'addToy');
INSERT INTO `menu` VALUES ('7', '用户管理', '1', null);
INSERT INTO `menu` VALUES ('8', '用户列表', '7', 'findUsers');
INSERT INTO `menu` VALUES ('9', '添加用户', '7', 'addUser');
INSERT INTO `menu` VALUES ('13', '订单管理', '1', null);
INSERT INTO `menu` VALUES ('14', '订单列表', '13', 'selectOrderList');
INSERT INTO `menu` VALUES ('15', '评论列表', '13', 'selectEvaluate');
INSERT INTO `menu` VALUES ('16', '待发货列表', '13', 'selectShipList');

-- ----------------------------
-- Table structure for `orderinfo`
-- ----------------------------
DROP TABLE IF EXISTS `orderinfo`;
CREATE TABLE `orderinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `toynoid` varchar(255) DEFAULT NULL COMMENT '订单编号',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `username` varchar(255) DEFAULT NULL COMMENT '用户名称',
  `toyid` int(11) DEFAULT NULL COMMENT '商品id',
  `toyname` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `buynum` int(11) DEFAULT NULL COMMENT '购买数量',
  `totalprice` double DEFAULT NULL COMMENT '总金额',
  `buydate` date DEFAULT NULL COMMENT '日期',
  `isevaluate` int(11) DEFAULT NULL COMMENT '是否评价 1：是  2：否',
  `evaluateid` int(11) DEFAULT NULL COMMENT '评价表id',
  `bz1` int(11) DEFAULT NULL COMMENT '支付成功待发货：1  购物车：2 确认收货：3  订单完成：4 待支付：5',
  `bz2` int(11) DEFAULT NULL COMMENT '类型',
  `bz3` varchar(255) DEFAULT NULL COMMENT '备注3  收货人姓名',
  `bz4` varchar(255) DEFAULT NULL COMMENT '备注4  收货人电话',
  `price` double DEFAULT NULL COMMENT '单价',
  `img` varchar(255) DEFAULT NULL COMMENT '照片',
  `bz5` varchar(255) DEFAULT NULL COMMENT '收货人地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderinfo
-- ----------------------------
INSERT INTO `orderinfo` VALUES ('95', '1585290064852', '28', 'ls', '17', '汉服', '1', '15', '2020-03-27', '2', null, '2', '4', null, null, '15', '12336f4274e845dfba0f5c9c7cd9dab9.jpg', null);
INSERT INTO `orderinfo` VALUES ('120', '1586861637947', '58', 'zhz', '21', '小熊熊', '1', '20', '2020-04-14', '2', null, '2', '4', null, null, '20', '23b693e26ab04ac89fef5b93afb20370.jpg', null);
INSERT INTO `orderinfo` VALUES ('138', '1588242324502', '50', 'ls', '56', '哈利波特', '1', '9.9', '2020-04-30', '2', null, '5', '1', '李赛', '13292912073', '9.9', 'd6d473ef3ef14a959f641257158b46f8.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('140', null, '50', 'ls', '56', '哈利波特', '1', '9.9', '2020-04-30', '2', null, '5', '1', '李赛', '13292912073', '9.9', 'd6d473ef3ef14a959f641257158b46f8.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('141', '1588242546492', '50', 'ls', '56', '哈利波特', '1', '9.9', '2020-05-09', '2', null, '5', '1', '李赛', '13292912073', '9.9', 'd6d473ef3ef14a959f641257158b46f8.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('143', '1589006582395', '50', 'ls', '88', '鳄鱼', '1', '67', '2020-05-09', '2', null, '5', '2', '李赛', '13292912073', '67', '2e7b0a9941f4472eadadb457a57f376d.jpeg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('144', null, '50', 'ls', '88', '鳄鱼', '1', '67', '2020-05-09', '2', null, '5', '2', '李赛', '13292912073', '67', '2e7b0a9941f4472eadadb457a57f376d.jpeg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('145', '1589006623188', '50', 'ls', '89', '大熊玩偶', '2', '56', '2020-05-09', '2', null, '5', '2', '李赛', '13292912073', '28', '5377bbbdf5ff43d4ad1c0624db9d2fb4.jpeg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('146', null, '50', 'ls', '89', '大熊玩偶', '1', '28', '2020-05-09', '2', null, '5', '2', '李赛', '13292912073', '28', '5377bbbdf5ff43d4ad1c0624db9d2fb4.jpeg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('147', '1589010025011', '50', 'ls', '89', '大熊玩偶', '1', '28', '2020-05-09', '2', null, '5', '2', '李赛', '13292912073', '28', '5377bbbdf5ff43d4ad1c0624db9d2fb4.jpeg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('148', '1589009288054', '50', 'ls', '55', '火影忍者我爱罗', '1', '179.99', '2020-05-09', '2', null, '1', '1', '李赛', '13292912073', '179.99', 'c8f18ffc0fa5434bb205dead07b5e442.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('149', null, '50', 'ls', '77', '十二花神发簪', '1', '79.9', '2020-05-09', '2', null, '5', '4', '李赛', '13292912073', '79.9', '12149aeb68a74c41916b7b10eaf2d636.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('150', '1589010206076', '50', 'ls', '97', '空竹', '1', '455', '2020-05-09', '2', null, '1', '3', '李赛', '13292912073', '455', '328e9435c94b40238af6a3a769b4c0be.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('152', '1589010335723', '50', 'ls', '90', '倒霉熊', '2', '152', '2020-05-09', '2', null, '5', '2', '李赛', '13292912073', '76', '682c1aea304a4ad3bc6ff5d401b6eca1.jpeg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('153', '1589010335723', '50', 'ls', '60', '乔巴', '2', '154', '2020-05-09', '2', null, '5', '1', '李赛', '13292912073', '77', '77a850b512294bb79323a57c1926cbf9.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('154', '1589438450413', '50', 'ls', '55', '火影忍者我爱罗', '2', '359.98', '2020-05-14', '2', null, '5', '1', '李赛', '13292912073', '179.99', 'c8f18ffc0fa5434bb205dead07b5e442.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('155', '1589438860114', '50', 'ls', '55', '火影忍者我爱罗', '2', '359.98', '2020-05-14', '2', null, '1', '1', '李赛', '13292912073', '179.99', 'c8f18ffc0fa5434bb205dead07b5e442.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('156', '1589438946220', '50', 'ls', '65', '数独六宫格', '2', '58', '2020-05-14', '2', null, '5', '5', '李赛', '13292912073', '29', '9621be1be03a4bb2923d80df87c817d9.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('157', '1589438946220', '50', 'ls', '66', '跳跳棋', '2', '60', '2020-05-14', '2', null, '5', '5', '李赛', '13292912073', '30', '23f6417f79d641f88ce97d87482c9d46.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('158', '1589439430060', '50', 'ls', '62', '凯', '1', '59', '2020-05-14', '2', null, '5', '1', '李赛', '13292912073', '59', 'c50a5962716e40ecb02b5c886c545635.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('159', null, '50', 'ls', '61', '盖伦', '1', '66.66', '2020-05-14', '2', null, '5', '1', '李赛', '13292912073', '66.66', 'ae685dd02aa74a48b005a43b31b56e73.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('160', '1589440546850', '50', 'ls', '64', '国际象棋', '1', '59', '2020-05-14', '2', null, '1', '5', '李赛', '13292912073', '59', '60d8323fab464a609a7316ec4c942079.jpeg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('161', '1589440818656', '50', 'ls', '67', '航母拼图', '1', '129', '2020-05-14', '2', null, '1', '5', '李赛', '13292912073', '129', 'f2d06ca882474ebea9d5f41952fd468c.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('162', '1589440818656', '50', 'ls', '68', '魔方', '2', '26', '2020-05-14', '1', '48', '4', '5', '李赛', '13292912073', '13', '9ce516438fb845b5903a5a49ae3b8d49.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('163', '1589441536670', '50', 'ls', '83', '七彩扇', '1', '65.5', '2020-05-14', '2', null, '3', '4', '李赛', '13292912073', '65.5', '6d451db3281544e2aaa2cd9445f132bf.jpg', '河北省唐山市路北区大学道唐山师范');
INSERT INTO `orderinfo` VALUES ('164', null, '50', 'ls', '54', '雪之下雪乃', '2', '7999.98', '2020-05-15', '2', null, '2', '1', null, null, '3999.99', '5c1c55660451469b9d6825c9ce3f0584.jpg', null);
INSERT INTO `orderinfo` VALUES ('165', null, '50', 'ls', '54', '雪之下雪乃', '2', '7999.98', '2020-05-15', '2', null, '2', '1', null, null, '3999.99', '5c1c55660451469b9d6825c9ce3f0584.jpg', null);
INSERT INTO `orderinfo` VALUES ('166', null, '50', 'ls', '54', '雪之下雪乃', '2', '7999.98', '2020-05-15', '2', null, '2', '1', null, null, '3999.99', '5c1c55660451469b9d6825c9ce3f0584.jpg', null);
INSERT INTO `orderinfo` VALUES ('167', null, '50', 'ls', '97', '空竹', '1', '455', '2020-05-15', '2', null, '2', '3', null, null, '455', '328e9435c94b40238af6a3a769b4c0be.jpg', null);
INSERT INTO `orderinfo` VALUES ('168', null, '66', 'test2', '71', '华容道', '1', '25', '2020-05-19', '2', null, '2', '5', null, null, '25', 'cf607ce483344c0ea07fb79e5dbc439d.jpg', null);
INSERT INTO `orderinfo` VALUES ('169', null, '66', 'test2', '67', '航母拼图', '2', '258', '2020-05-19', '2', null, '2', '5', null, null, '129', 'f2d06ca882474ebea9d5f41952fd468c.jpg', null);
INSERT INTO `orderinfo` VALUES ('173', null, '70', 'test', '96', '波浪鼓', '2', '70', '2020-05-19', '2', null, '2', '3', null, null, '35', '2f7833a9cfeb45e3868978dce323d49e.jpg', null);
INSERT INTO `orderinfo` VALUES ('174', null, '70', 'test', '87', '树袋熊玩偶', '3', '288', '2020-05-19', '2', null, '2', '2', null, null, '96', 'f8cedbe94cf649faa864d8b719ed6115.jpeg', null);
INSERT INTO `orderinfo` VALUES ('179', null, '73', 'test', '89', '大熊玩偶', '2', '56', '2020-05-19', '2', null, '2', '2', null, null, '28', '5377bbbdf5ff43d4ad1c0624db9d2fb4.jpeg', null);
INSERT INTO `orderinfo` VALUES ('182', null, '74', 'test', '60', '乔巴', '2', '154', '2020-05-19', '2', null, '2', '1', null, null, '77', '77a850b512294bb79323a57c1926cbf9.jpg', null);
INSERT INTO `orderinfo` VALUES ('187', null, '82', 'test', '61', '盖伦', '1', '66.66', '2020-05-23', '2', null, '5', '1', '李赛', '123', '66.66', 'ae685dd02aa74a48b005a43b31b56e73.jpg', 'QQQQ群');
INSERT INTO `orderinfo` VALUES ('188', null, '82', 'test', '58', '甄姬', '1', '88.88', '2020-05-23', '2', null, '5', '1', '李赛', '123', '88.88', '9ab4d6ed2fe2417a8030c507ffbec23c.jpg', 'QQQQ群');
INSERT INTO `orderinfo` VALUES ('189', null, '82', 'test', '60', '乔巴', '1', '77', '2020-05-23', '2', null, '2', '1', null, null, '77', '77a850b512294bb79323a57c1926cbf9.jpg', null);
INSERT INTO `orderinfo` VALUES ('190', null, '82', 'test', '53', '刀剑神域桐人手办', '1', '199.99', '2020-05-23', '2', null, '2', '1', null, null, '199.99', '4a21ccc71aa34080aeeffa43e302ef4c.png', null);

-- ----------------------------
-- Table structure for `role`
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', '超级管理员');
INSERT INTO `role` VALUES ('2', '普通用户');

-- ----------------------------
-- Table structure for `role_menu`
-- ----------------------------
DROP TABLE IF EXISTS `role_menu`;
CREATE TABLE `role_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menuId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_menu
-- ----------------------------
INSERT INTO `role_menu` VALUES ('1', '2', '1');
INSERT INTO `role_menu` VALUES ('2', '3', '1');
INSERT INTO `role_menu` VALUES ('3', '4', '1');
INSERT INTO `role_menu` VALUES ('4', '5', '1');
INSERT INTO `role_menu` VALUES ('5', '6', '1');
INSERT INTO `role_menu` VALUES ('6', '7', '1');
INSERT INTO `role_menu` VALUES ('7', '8', '1');
INSERT INTO `role_menu` VALUES ('8', '9', '1');
INSERT INTO `role_menu` VALUES ('9', '7', '2');
INSERT INTO `role_menu` VALUES ('10', '8', '2');
INSERT INTO `role_menu` VALUES ('11', '9', '2');
INSERT INTO `role_menu` VALUES ('12', '10', '1');
INSERT INTO `role_menu` VALUES ('13', '11', '1');
INSERT INTO `role_menu` VALUES ('14', '12', '1');
INSERT INTO `role_menu` VALUES ('15', '13', '1');
INSERT INTO `role_menu` VALUES ('16', '14', '1');
INSERT INTO `role_menu` VALUES ('17', '15', '1');
INSERT INTO `role_menu` VALUES ('18', '16', '1');
INSERT INTO `role_menu` VALUES ('19', '17', '1');
INSERT INTO `role_menu` VALUES ('20', '18', '1');
INSERT INTO `role_menu` VALUES ('21', '19', '1');
INSERT INTO `role_menu` VALUES ('22', '20', '1');
INSERT INTO `role_menu` VALUES ('23', '21', '1');
INSERT INTO `role_menu` VALUES ('24', '22', '1');
INSERT INTO `role_menu` VALUES ('25', '10', '2');
INSERT INTO `role_menu` VALUES ('26', '11', '2');
INSERT INTO `role_menu` VALUES ('27', '13', '2');
INSERT INTO `role_menu` VALUES ('28', '14', '2');
INSERT INTO `role_menu` VALUES ('29', '15', '2');
INSERT INTO `role_menu` VALUES ('30', '16', '2');
INSERT INTO `role_menu` VALUES ('31', '17', '2');
INSERT INTO `role_menu` VALUES ('32', '18', '2');
INSERT INTO `role_menu` VALUES ('33', '19', '2');
INSERT INTO `role_menu` VALUES ('34', '20', '2');
INSERT INTO `role_menu` VALUES ('35', '21', '2');
INSERT INTO `role_menu` VALUES ('36', '5', '3');
INSERT INTO `role_menu` VALUES ('37', '10', '2');
INSERT INTO `role_menu` VALUES ('38', '11', '2');
INSERT INTO `role_menu` VALUES ('39', '13', '2');
INSERT INTO `role_menu` VALUES ('40', '14', '2');
INSERT INTO `role_menu` VALUES ('41', '15', '2');
INSERT INTO `role_menu` VALUES ('42', '16', '2');
INSERT INTO `role_menu` VALUES ('43', '17', '2');
INSERT INTO `role_menu` VALUES ('44', '18', '2');
INSERT INTO `role_menu` VALUES ('45', '19', '2');
INSERT INTO `role_menu` VALUES ('46', '20', '2');
INSERT INTO `role_menu` VALUES ('47', '21', '2');

-- ----------------------------
-- Table structure for `toyinfo`
-- ----------------------------
DROP TABLE IF EXISTS `toyinfo`;
CREATE TABLE `toyinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `toyname` varchar(255) DEFAULT '' COMMENT '商品名称',
  `price` double DEFAULT NULL COMMENT '价格',
  `toytype` int(11) DEFAULT NULL COMMENT '商品类型（1：手办 2：布偶抱枕 3：传统古风 4：缤纷服饰 5：创意益智）',
  `istop` int(11) DEFAULT '2' COMMENT '是否上主页 1：是  2：否',
  `isdown` int(11) DEFAULT '2' COMMENT '是否上架 1是  2 否',
  `totalnum` int(11) DEFAULT NULL COMMENT '总量',
  `num` int(11) DEFAULT '0' COMMENT '已卖出数量',
  `img` varchar(255) DEFAULT NULL COMMENT '照片',
  `bz1` int(11) DEFAULT NULL COMMENT '剩余量',
  `bz2` varchar(255) DEFAULT NULL COMMENT '简介',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of toyinfo
-- ----------------------------
INSERT INTO `toyinfo` VALUES ('51', '赛丽亚手办', '49.9', '1', '2', '2', '2', '0', '0fcc0fe89eff4dcf9fdea5f189a8277a.jpg', null, '地下城与勇士精品手办');
INSERT INTO `toyinfo` VALUES ('52', '大唐风情服饰', '89.9', '4', '2', '1', '100', '0', '92d9942368a149f7b90d39f8710fbd5a.jpg', null, '唐代风格');
INSERT INTO `toyinfo` VALUES ('53', '刀剑神域桐人手办', '199.99', '1', '2', '1', '100', '2', '4a21ccc71aa34080aeeffa43e302ef4c.png', null, '动漫刀剑神域主人公桐人手办');
INSERT INTO `toyinfo` VALUES ('55', '火影忍者我爱罗', '179.99', '1', '1', '1', '100', '8', 'c8f18ffc0fa5434bb205dead07b5e442.jpg', null, '动漫火影忍者角色我爱罗');
INSERT INTO `toyinfo` VALUES ('56', '哈利波特', '9.9', '1', '2', '2', '100', '5', 'd6d473ef3ef14a959f641257158b46f8.jpg', null, '哈利波特手办');
INSERT INTO `toyinfo` VALUES ('57', '金克斯', '79.9', '1', '2', '2', '100', '1', 'edf0cf643c5445b8941f8e418fc4c214.jpg', null, '游戏英雄联盟里的角色');
INSERT INTO `toyinfo` VALUES ('58', '甄姬', '88.88', '1', '2', '1', '100', '0', '9ab4d6ed2fe2417a8030c507ffbec23c.jpg', null, '游戏王者荣耀里的角色');
INSERT INTO `toyinfo` VALUES ('59', '亚斯娜', '198', '1', '2', '1', '100', '2', 'd5b09d54dd6b4a74a64bb2f884070598.png', null, '动漫刀剑神域中的角色');
INSERT INTO `toyinfo` VALUES ('60', '乔巴', '77', '1', '2', '1', '100', '0', '77a850b512294bb79323a57c1926cbf9.jpg', null, '动漫海贼王角色');
INSERT INTO `toyinfo` VALUES ('61', '盖伦', '66.66', '1', '1', '1', '100', '2', 'ae685dd02aa74a48b005a43b31b56e73.jpg', null, '游戏英雄联盟德玛西亚之力');
INSERT INTO `toyinfo` VALUES ('62', '凯', '59', '1', '1', '1', '100', '1', 'c50a5962716e40ecb02b5c886c545635.jpg', null, '游戏王者荣耀');
INSERT INTO `toyinfo` VALUES ('64', '国际象棋', '59', '5', '2', '1', '100', '4', '60d8323fab464a609a7316ec4c942079.jpeg', null, '国际象棋');
INSERT INTO `toyinfo` VALUES ('65', '数独六宫格', '29', '5', '2', '1', '100', '0', '9621be1be03a4bb2923d80df87c817d9.jpg', null, '数独六宫格 益智玩具');
INSERT INTO `toyinfo` VALUES ('66', '跳跳棋', '30', '5', '1', '1', '100', '0', '23f6417f79d641f88ce97d87482c9d46.jpg', null, '居家旅行休闲玩具');
INSERT INTO `toyinfo` VALUES ('67', '航母拼图', '129', '5', '2', '1', '100', '1', 'f2d06ca882474ebea9d5f41952fd468c.jpg', null, '立体航母拼图玩具');
INSERT INTO `toyinfo` VALUES ('68', '魔方', '13', '5', '1', '1', '100', '2', '9ce516438fb845b5903a5a49ae3b8d49.jpg', null, '三阶魔方');
INSERT INTO `toyinfo` VALUES ('69', '五子棋', '15', '5', '2', '1', '100', '0', 'e2607b1e1e984758aaa132146b933854.jpg', null, '创新原型棋盘');
INSERT INTO `toyinfo` VALUES ('70', '围棋', '69', '5', '2', '1', '100', '0', '8268bf716d294b238d26d330eb5fd025.jpg', null, '精美围棋');
INSERT INTO `toyinfo` VALUES ('71', '华容道', '25', '5', '2', '1', '100', '0', 'cf607ce483344c0ea07fb79e5dbc439d.jpg', null, '三国故事曹操败走华容道，转动你的大脑逃出生天吧！');
INSERT INTO `toyinfo` VALUES ('72', '中国象棋', '35', '5', '1', '1', '100', '2', '7aff4e0fa97149d4ad1feaa918003c80.jpg', null, '楚河汉界，争霸天下');
INSERT INTO `toyinfo` VALUES ('73', '异形魔方', '19', '5', '1', '1', '100', '0', 'f48d1c92dd7f44ef9b2369f94c8b7114.png', null, '异形魔方，更加烧脑哦！');
INSERT INTO `toyinfo` VALUES ('74', '恐龙拼图', '67', '5', '2', '1', '100', '0', 'd8ea83c85e544af0a2f0e730875b4ab1.jpg', null, '精美恐龙拼图');
INSERT INTO `toyinfo` VALUES ('75', '冰雪城堡', '119', '5', '2', '1', '100', '0', '4d899d2f1a1046a39a9f5e032a8788d1.jpg', null, '冰雪城堡积木，搭建精致城堡');
INSERT INTO `toyinfo` VALUES ('76', '积木拼图', '28', '5', '2', '1', '100', '0', '3fb7ba26501748fe94fdca4d51ce447d.jpg', null, '积木拼图，快快动手吧！');
INSERT INTO `toyinfo` VALUES ('77', '十二花神发簪', '79.9', '4', '1', '1', '100', '0', '12149aeb68a74c41916b7b10eaf2d636.jpg', null, '十二花神发簪系列，十二种风格，搭配各种不一样的服饰，值得拥有！');
INSERT INTO `toyinfo` VALUES ('78', '复古扇', '78.8', '4', '1', '1', '100', '0', '2c7342afbf3e4c07b3847e31d8167e0f.jpg', null, '素是自然色,圆因裁制功.飒如松起籁,飘似鹤翻空. 盛夏不销雪,终年无尽风.引秋生手里,藏月入怀中！');
INSERT INTO `toyinfo` VALUES ('79', '民国风服饰', '566', '4', '2', '1', '100', '0', 'b5e70ba79f8f40c6914d02233471f02c.jpg', null, '阅尽天涯离别苦，不道归来，零落花如许。花底相看无一语，绿窗春与天俱莫。待把相思灯下诉，一缕新欢，旧恨千千缕。最是人间留不住，朱颜辞镜花辞树。');
INSERT INTO `toyinfo` VALUES ('80', '古风红裙', '788', '4', '2', '1', '100', '0', 'a9b4dd13bbde46a6b46e45f0dffcd42a.jpg', null, '画罗织扇总如云,细草如泥簇蝶裙');
INSERT INTO `toyinfo` VALUES ('81', '小红帽', '55', '4', '1', '1', '100', '0', '3a55a40c2a844dd7a73770a41e0680ce.jpg', null, '童话故事小红帽与大灰狼中的小红帽！');
INSERT INTO `toyinfo` VALUES ('82', '艾莎', '999', '4', '2', '1', '100', '0', '2a0e2bc436344a92b16e5cbb11b8ac44.jpg', null, '冰雪奇缘主人公艾莎服饰');
INSERT INTO `toyinfo` VALUES ('83', '七彩扇', '65.5', '4', '1', '1', '100', '1', '6d451db3281544e2aaa2cd9445f132bf.jpg', null, '多种颜色，做工精美，时尚新颖！');
INSERT INTO `toyinfo` VALUES ('84', '囍', '888', '4', '2', '1', '100', '0', '8e09200cbe37418b9383e0d9e4d448c0.jpg', null, '婚庆可用！');
INSERT INTO `toyinfo` VALUES ('85', '连衣裙', '466', '4', '2', '1', '100', '0', '31f2171e816e47289948e260abe9e198.jpg', null, '古风连衣裙，蓝色的淡雅！');
INSERT INTO `toyinfo` VALUES ('86', '蝙蝠侠', '5.5', '4', '2', '1', '100', '0', 'd2a6251e58004b57b0b8d64b668cc793.jpg', null, '蝙蝠侠服饰！');
INSERT INTO `toyinfo` VALUES ('87', '树袋熊玩偶', '96', '2', '2', '1', '100', '1', 'f8cedbe94cf649faa864d8b719ed6115.jpeg', null, '树袋熊玩偶！');
INSERT INTO `toyinfo` VALUES ('88', '鳄鱼', '67', '2', '2', '1', '100', '0', '2e7b0a9941f4472eadadb457a57f376d.jpeg', null, '鳄鱼玩偶');
INSERT INTO `toyinfo` VALUES ('89', '大熊玩偶', '28', '2', '1', '1', '100', '0', '5377bbbdf5ff43d4ad1c0624db9d2fb4.jpeg', null, '足够大！');
INSERT INTO `toyinfo` VALUES ('90', '倒霉熊', '76', '2', '2', '1', '100', '0', '682c1aea304a4ad3bc6ff5d401b6eca1.jpeg', null, '倒霉熊布偶玩具');
INSERT INTO `toyinfo` VALUES ('91', '奶瓶抱枕', '298', '2', '1', '1', '100', '0', '384e52d2515d43e692cf7aacc590c213.jpeg', null, '可当抱枕可当靠枕');
INSERT INTO `toyinfo` VALUES ('92', '粉色布偶熊', '356', '2', '2', '1', '100', '0', '8698a006814a4ca4be2754abd5c3bd78.jpg', null, '粉色布偶熊，不一样的颜色，不一样的心情！');
INSERT INTO `toyinfo` VALUES ('93', '安琪', '378', '2', '1', '1', '100', '0', 'abbb81571db1414e817f8654d0f453b6.jpg', null, '星际宝贝超人气角色！');
INSERT INTO `toyinfo` VALUES ('94', '史迪仔与他的女朋友', '798', '2', '2', '1', '100', '0', 'fd5c75bc4b3a4204ae0c419f41da86b2.jpg', null, '史迪仔与他的女朋友！');
INSERT INTO `toyinfo` VALUES ('95', '萌萌熊', '258', '2', '2', '1', '100', '0', '27b6fb9ab5e64a8e842c46c7937bd5b5.jpeg', null, '穿衣服的布偶熊更萌哦！');
INSERT INTO `toyinfo` VALUES ('96', '波浪鼓', '35', '3', '1', '1', '100', '1', '2f7833a9cfeb45e3868978dce323d49e.jpg', null, '传统玩具！爱不释手！');
INSERT INTO `toyinfo` VALUES ('97', '空竹', '455', '3', '2', '1', '100', '1', '328e9435c94b40238af6a3a769b4c0be.jpg', null, '休闲解压！抖一抖！');
INSERT INTO `toyinfo` VALUES ('98', '金鱼风筝', '148', '3', '2', '1', '100', '0', 'dac5c273fd0e4388b8e2ba142402d449.jpg', null, '金鱼风筝，随风飘扬！');
INSERT INTO `toyinfo` VALUES ('99', '萧', '898', '3', '2', '1', '100', '0', '119bc60727d54e49ab8ec00b5602d0b0.jpg', null, '传统乐器！');
INSERT INTO `toyinfo` VALUES ('100', '竹蜻蜓', '46.9', '3', '2', '1', '100', '0', '53f4a5bcc01f450a9a29bf727552d8d7.jpg', null, '你是否也想飞上天呢？');
INSERT INTO `toyinfo` VALUES ('101', '陀螺', '76.9', '3', '2', '1', '100', '0', 'f77bff3405d04b75b76e4eb5c60635a4.jpg', null, '转啊转！');
INSERT INTO `toyinfo` VALUES ('102', '毽子', '88.9', '3', '2', '1', '100', '0', '5c5dc4aca2454010a9ee3efd9c917d79.jpg', null, '踢毽子是一项很好的健身运动！');
INSERT INTO `toyinfo` VALUES ('103', '快板', '65.9', '3', '1', '1', '100', '0', 'a4455cd4916f41d88e646904247a1378.jpg', null, '快板这么一打，别的咱不夸，咱就夸一夸咱这快板响不响！');
INSERT INTO `toyinfo` VALUES ('104', '不倒翁', '322', '3', '2', '1', '100', '0', 'c39424a49e024382b918669a1814e856.jpg', null, '不倒翁真的就放不倒吗？');
INSERT INTO `toyinfo` VALUES ('105', '翻花绳', '14.9', '3', '2', '1', '100', '0', 'dda00400ccb44837bc7a034b4d0a8a68.jpg', null, '你会翻多少种花绳子呢？');
INSERT INTO `toyinfo` VALUES ('106', '泥人', '9999.99', '3', '2', '1', '100', '0', '1ffd5de5d05d484fad58a87cc87318ef.jpg', null, '泥人可是传统文化哦！');
INSERT INTO `toyinfo` VALUES ('107', '跳皮筋', '3', '3', '2', '1', '100', '0', 'a28096669be349b3aef024af176773de.jpg', null, '午后约几个小伙伴，你们能跳多少层呢？');
INSERT INTO `toyinfo` VALUES ('108', '蝙蝠侠', '11111', '1', '2', '2', '100', '0', 'cbfb54bf52564d658f904ba77e4ace9b.png', null, '蝙蝠侠');
INSERT INTO `toyinfo` VALUES ('109', '暗夜使者', '1321', '1', '2', '2', '100', '0', 'b518dd14732e4df1a00f96f2027443ca.jpg', null, '暗夜使者');
INSERT INTO `toyinfo` VALUES ('111', '雪之下雪乃', '3999.99', '1', '1', '2', '100', '0', '624a4b19700c40888a48da76683a318c.jpg', null, '人气动漫角色雪之下雪乃');
INSERT INTO `toyinfo` VALUES ('116', 'test', '2', '1', '1', '1', '100', '0', 'f5e70584a1214549aae1990777b4eb17.jpg', null, 'test');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `username` varchar(255) DEFAULT NULL COMMENT '用户名',
  `userpwd` varchar(255) DEFAULT NULL COMMENT '密码',
  `realname` varchar(255) DEFAULT 'tx.png' COMMENT '头像',
  `identity` varchar(255) DEFAULT NULL COMMENT '收件人手机号',
  `sex` varchar(255) DEFAULT NULL COMMENT '性别',
  `address` varchar(255) DEFAULT NULL COMMENT '收件人地址',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `position` varchar(255) DEFAULT NULL COMMENT '收件人姓名',
  `roleid` varchar(255) DEFAULT NULL COMMENT '角色',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', 'admin', '李赛', 'admin', '男', '修改dasd', 'admin', 'CEO', '1');
INSERT INTO `user` VALUES ('50', 'ls', '123', '83eaa41a6639464da22b5570ce8a1ec6.JPG', '13292912073', null, '河北省唐山市路北区大学道唐山师范', '13292912073', '李赛', '2');
INSERT INTO `user` VALUES ('52', 'lt', '123', '01bb0bb15f4b411bad98d5843d6250aa.jpg', '123', null, '123', '13292912073', '123', '2');
INSERT INTO `user` VALUES ('56', 'szj', '123', 'tx.png', null, null, null, '13292912073', null, '2');
INSERT INTO `user` VALUES ('58', 'zhz', '123', 'tx.png', '2', null, '3', '13292912073', '1', '2');
INSERT INTO `user` VALUES ('59', 'tt', '123', 'tx.png', null, null, null, '13292912073', null, '2');
INSERT INTO `user` VALUES ('61', 'qs', '123', 'tx.png', '去去去', null, '去去去', '13292912073', '确实', '2');
INSERT INTO `user` VALUES ('80', 'lisai', '111', 'tx.png', null, null, null, '13292912073', null, '2');
INSERT INTO `user` VALUES ('81', 'lisa', '123', 'tx.png', null, null, null, '13292912073', null, '2');
INSERT INTO `user` VALUES ('82', 'test', '123456', '76bd155d0db64f30bde1cae4bd6d2aa2.jpg', '123', null, 'QQQQ群', '13292912073', '李赛', '2');
INSERT INTO `user` VALUES ('83', '111', '2222', 'tx.png', null, null, null, '13292912073', null, '2');
