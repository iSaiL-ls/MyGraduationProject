package com.mywork.pojo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Orderinfo {
    private Integer id;
    
    private Integer evalid;
    
    private String toynoid;

    private Integer userid;
    //评价
    private String evaluate;
    //打分
    private Integer scoring;

    private String username;

    private Integer toyid;

    private String toyname;

    private Integer buynum;

    private Double totalprice;
    
    /** 当前记录起始索引 */
    private Integer pageNum = 1;
    /** 每页显示记录数 */
    private Integer pageSize = 2;

    @DateTimeFormat(pattern="yyyy-MM-dd")
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date buydate;
    
    private Integer isevaluate;

    private Integer evaluateid;

    private Integer bz1;

    private Integer bz2;

    private String bz3;

    private String bz4;
    
    private String bz5;
    

    private Double price;
    
    private String img;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getToynoid() {
        return toynoid;
    }

    public void setToynoid(String toynoid) {
        this.toynoid = toynoid;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public Integer getToyid() {
        return toyid;
    }

    public void setToyid(Integer toyid) {
        this.toyid = toyid;
    }

    public String getToyname() {
        return toyname;
    }

    public void setToyname(String toyname) {
        this.toyname = toyname == null ? null : toyname.trim();
    }

    public Integer getBuynum() {
        return buynum;
    }

    public void setBuynum(Integer buynum) {
        this.buynum = buynum;
    }

    public Double getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(Double totalprice) {
        this.totalprice = totalprice;
    }

    public Date getBuydate() {
        return buydate;
    }

    public void setBuydate(Date buydate) {
        this.buydate = buydate;
    }

    public Integer getIsevaluate() {
        return isevaluate;
    }

    public void setIsevaluate(Integer isevaluate) {
        this.isevaluate = isevaluate;
    }

    public Integer getEvaluateid() {
        return evaluateid;
    }

    public void setEvaluateid(Integer evaluateid) {
        this.evaluateid = evaluateid;
    }

    public Integer getBz1() {
        return bz1;
    }

    public void setBz1(Integer bz1) {
        this.bz1 = bz1;
    }

    public Integer getBz2() {
        return bz2;
    }

    public void setBz2(Integer bz2) {
        this.bz2 = bz2;
    }

    public String getBz3() {
        return bz3;
    }

    public void setBz3(String bz3) {
        this.bz3 = bz3 == null ? null : bz3.trim();
    }

    public String getBz4() {
        return bz4;
    }

    public void setBz4(String bz4) {
        this.bz4 = bz4 == null ? null : bz4.trim();
    }

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getEvaluate() {
		return evaluate;
	}

	public void setEvaluate(String evaluate) {
		this.evaluate = evaluate;
	}

	public Integer getScoring() {
		return scoring;
	}

	public void setScoring(Integer scoring) {
		this.scoring = scoring;
	}

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getEvalid() {
		return evalid;
	}

	public void setEvalid(Integer evalid) {
		this.evalid = evalid;
	}

	public String getBz5() {
		return bz5;
	}

	public void setBz5(String bz5) {
		this.bz5 = bz5;
	}
    
    
}