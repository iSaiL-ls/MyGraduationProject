package com.mywork.pojo;

import java.util.Date;

public class Evaluate {
    private Integer id;
    
    private Integer orderid;
    
    private Integer toyid;

    private String toynoid;

    private Integer userid;

    private Integer scoring;

    private Integer bz1;

    private Integer bz2;

    private String bz3;

    private String bz4;

    private Date bz5;
    
    private String bz6;
    private String evaluate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getToyid() {
        return toyid;
    }

    public void setToyid(Integer toyid) {
        this.toyid = toyid;
    }

    public String getToynoid() {
        return toynoid;
    }

    public void setToynoid(String toynoid) {
        this.toynoid = toynoid == null ? null : toynoid.trim();
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Integer getScoring() {
        return scoring;
    }

    public void setScoring(Integer scoring) {
        this.scoring = scoring;
    }

    public Integer getBz1() {
        return bz1;
    }

    public void setBz1(Integer bz1) {
        this.bz1 = bz1;
    }

    public Integer getBz2() {
        return bz2;
    }

    public void setBz2(Integer bz2) {
        this.bz2 = bz2;
    }

    public String getBz3() {
        return bz3;
    }

    public void setBz3(String bz3) {
        this.bz3 = bz3 == null ? null : bz3.trim();
    }

    public String getBz4() {
        return bz4;
    }

    public void setBz4(String bz4) {
        this.bz4 = bz4 == null ? null : bz4.trim();
    }

    public Date getBz5() {
        return bz5;
    }

    public void setBz5(Date bz5) {
        this.bz5 = bz5;
    }

    public String getEvaluate() {
        return evaluate;
    }

    public void setEvaluate(String evaluate) {
        this.evaluate = evaluate == null ? null : evaluate.trim();
    }

	public Integer getOrderid() {
		return orderid;
	}

	public void setOrderid(Integer orderid) {
		this.orderid = orderid;
	}

	public String getBz6() {
		return bz6;
	}

	public void setBz6(String bz6) {
		this.bz6 = bz6;
	}
	
	
}