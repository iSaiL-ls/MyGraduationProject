package com.mywork.interceptor;

import javax.servlet.http.HttpServletRequest;

import com.mywork.pojo.Logtable;
import com.mywork.pojo.User;

import java.text.SimpleDateFormat;
import java.util.Date;

public class BaseLogtable {

	Logtable logtable = new Logtable();
	
	public void setLogtable(HttpServletRequest request) {
		User user = (User)request.getSession().getAttribute("currentUser");
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateTime = sdf.format(date);
		logtable.setUserid(user.getUserid());
		logtable.setUsername(user.getUsername());
		logtable.setActiontime(dateTime);
	}
}
