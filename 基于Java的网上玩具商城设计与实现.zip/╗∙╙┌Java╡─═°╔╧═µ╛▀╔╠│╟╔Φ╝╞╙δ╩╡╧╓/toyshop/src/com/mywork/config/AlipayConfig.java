﻿package com.mywork.config;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
	 // 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号,开发时使用沙箱提供的APPID，生产环境改成自己的APPID
    public static String APP_ID = "2016101800717365";

    // 商户私钥，您的PKCS8格式RSA2私钥
    public static String APP_PRIVATE_KEY = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDBSP9KXZdn24l6y5r59h5DU39+QUgA6gtRvBsLNvGBuyCDmlf4fftiIlpeaLbBQdNlfsj6Emnk/kP3LGU+rEdg4xe0DZ/EwCOTub6oAnJ7H2yFGD/jXHNNY9PEv2juKVVC9EQpnDbWr1mLF35RIjz59WyH3f16eKW0gZOMOnbMZpo9mp0PKb2uvi5aJ91cWy/OyrDTRDwmTtH/V3eh3d2U36vWFlrMXjrbOkj3UnXu8tAd69szuj6P9Wlh8oeS38E0dYlb5P1yJF78kjFpDh3E04lY99rsQTcbDaj56CSwoePouLeoc3ffjuOEzU50WoHxjdLf+a7XW/9FJFu1QCzvAgMBAAECggEAbZUZR+wv/u30z+3He5gSKFGaotYYIIyQxlJDcuQ/oDGbiYFkBrpGX6jiW0w68O6FD7IF9+Ggr/eISQaekB3UihW2RprCziWxBfv1IAPjK/Lw77SD5D9yD5pdYdqzfvNoJ4Gdc4nhfW4E8lrrfsxOjdibI5y0LU9hgylDoekzmUZE7f0l8codvI/LbQnHp2rxvV9xOnYvZOj1RxrjYkA1YTpHx+YYwTGiChBS0MIQfQS60rARz+74ZYOanfIxNtubzlTE1aQlWCs0Fw9pcOyD8f8bhAmvhBJM1PSL63AfYDVItRPZ7B3WYK1+rnabnnObRAZ82AIyV3myCbyn+LshgQKBgQD2vSURVYQ6G8RGJlCBRoOQNKbKqyRcQZIGQIy2Hi0GcQUobENo0Ua4KgOT/t1ueUJGWf+gLPbIXBVXndtCMYFOyPawQan6TrMFE+WZiRPAPW9RZjF8iKV6aPfmSKvKoAp9mYMtiPhstVpDMGO91yEnenl3z5izjzvUbb8ivUtAPwKBgQDIijp8ffrXZECY4W4a9Dq4J8mtz+ISzVZJf63+hfQWi2WZXP70Bm4NdNCJsdf8lH4iCRO/VuauMz3MXEvcO9PG4Ff+tF0qWnmsIXpLM77Npq2SS1CxW8vno3EBASFhFxdE8jg4PnWKxoYYtbdLvFgSA4nAy99hdfTxk6K5OIjnUQKBgCK4Pu0PgYnDuny8i3uFdqHmJspCBt3MhEXI84P0/xT29mjXwyyOtkrX7qT2qiYPfhn0NBpP+XH8MyyfE+lemfmCIeRveQG17U77m8VdGqBkhLOJk9EYUWDGQIvxEetzVcaSwXi422xAoLDvsDlYelvZyhnn5m7t6tdbkhfLVzl1AoGATey4kUt6v1urZjyixkKE1q5PRgTzeg7kKqc8exyeHmyITDHAuB4PgZcUuYyruvAQmzUfwUgJV0N+Df0HVUrCHhNq3gRD94M0qFhR5wryZ4MPCzvM3T4oW5g8/wDrcYjBd/8PLXvHvOcrkEp8MSe8qTNKwen2oS5uwbh2kLaRLCECgYBT0tt3Pi3V8cb79f24eDgI0ejjiMrPU5v69DyFSEjBuriFhMYTpSTHRDeOjCiYb6jrD5FFUIJSLtVpDfiZEkbhguTr7JuOe0tG04tWdYGbpJLOd1LsGQ1D2CjOnvgAcoFTwI2xMKHjroSuvQF6DjUt2jP9ahnIH09cRuVUk819iA==";

    // 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String ALIPAY_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAki4IV1UwA2hpMGw4h+KsmpDw+wTWu+63ZUKiI0xa5Hmm70ijYq98diNmgqiCR+2CX/dokdUtNOkMnOryL8G2sfk7rpRpY2BhoNsqSXmzOlKkEaOXaZzOthbHuSsFwJxBiafGXOn5DWRsYgfJi3kkNiZVrTeGby+ZENzwYBWbszN8nbe/AkSB8NwKJECr+09mM/0CpJjmI6WOM2Rf+jQ41pruprk63vV0qT+S4qLJ1jH365b6KCZn/thHaw6x4AJV+3CPp51ot+o5A9h+FHoE91IsDD0D+sGOkLfVt9AzniWx5UVACPiAH97eq/HvIhcTybJ0YbVgHC42dY+y2JRJZwIDAQAB";

    // 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
    public static String notify_url = "http://localhost:8080/index";

    // 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问(其实就是支付成功后返回的页面)
    public static String return_url = "http://localhost:8080/toyshop/orderReturn";

    // 签名方式
    public static String sign_type = "RSA2";

    // 字符编码格式
    public static String CHARSET = "utf-8";

    // 支付宝网关，这是沙箱的网关
    public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";

    // 支付宝网关
    public static String log_path = "C:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /**
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
	
}

