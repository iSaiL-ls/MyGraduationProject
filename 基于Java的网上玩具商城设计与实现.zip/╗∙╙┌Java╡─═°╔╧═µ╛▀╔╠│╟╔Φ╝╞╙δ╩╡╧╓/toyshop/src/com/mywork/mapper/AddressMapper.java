package com.mywork.mapper;

import java.util.List;

import com.mywork.pojo.Address;

public interface AddressMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Address record);

    Address selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Address record);

    int updateByPrimaryKey(Address record);
    
    /**
     * 新增地址
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    int insertSelective(Address record);
    
    /**
     * 根据userid查询
     * @Description:  
     * @author: 李赛
     * @param userid
     * @return
     */
    List<Address> selectByUserid(Integer userid);
    
}