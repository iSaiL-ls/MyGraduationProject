package com.mywork.mapper;

import java.util.List;

import com.mywork.pojo.Orderinfo;

public interface OrderinfoMapper {

    int insert(Orderinfo record);

    /**
     * 根据id查询
     * @Description:  
     * @author: 李赛
     * @param id
     * @return
     */
    Orderinfo selectByPrimaryKey(Integer id);

   

    int updateByPrimaryKey(Orderinfo record);
    
    /**
     * @Description:  新增订单
     * @author: 李赛
     * @param record
     * @return
     */
    int insertSelective(Orderinfo record);
    
    /**
     * @Description: 查询订单列表
     * @author: 李赛
     * @param userid
     * @return
     */
    List<Orderinfo> selectByUserId(Orderinfo record);
    
    /**
     * 根据主键更新订单表
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Orderinfo record);
    
    /**
     * 根据主键删除
     * @Description:  
     * @author: 李赛
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);
    
    /**
     * 查询数量
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    List<Orderinfo> selectcount(Orderinfo record);
    
    /**
     * @Description: 查询订单列表
     * @author: 李赛
     * @param userid
     * @return
     */
    List<Orderinfo> selectByUserIdPage(Orderinfo record);
    
    
    /**
     * 查询所有订单
     * @Description:  
     * @author: 李赛
     * @return
     */
    List<Orderinfo> selectAllOrderList();
    
    /**
     * 后台根据用户名和订单号查询
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    List<Orderinfo> selectOrderInfo(Orderinfo record);
    
    
    
    
    /**
     * 查询所有已支付订单
     * @Description:  
     * @author: 李赛
     * @return
     */
    List<Orderinfo> selectIsShipList();
    
    
    /**
     * 更新订单状态
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    int updateShip(Orderinfo record);
    
    /**
     * 查询订单
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    List<Orderinfo> selectByStatus(Orderinfo record);

    /**
     * 查询购物车
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    List<Orderinfo> selectCart(Orderinfo record);

    /**
     * 查询列表评论
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    List<Orderinfo> selectEvaluateInfo(Orderinfo record);
    
    /*
     * 查询销量
     */
    int selectOrderCount();
    
    /*
     * 查询总销量
     */
    int selectOrderCountAll();
    
    
    /**
     * @Description: 查询未评价订单列表
     * @author: 李赛
     * @param userid
     * @return
     */
    List<Orderinfo> selectNotEvaluate(Orderinfo record);
    
    
}