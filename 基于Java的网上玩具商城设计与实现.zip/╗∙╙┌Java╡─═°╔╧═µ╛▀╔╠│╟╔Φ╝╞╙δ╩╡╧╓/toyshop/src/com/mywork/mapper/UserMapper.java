package com.mywork.mapper;

import java.util.List;

import com.mywork.pojo.User;

public interface UserMapper {

	/**
	 * @Description:  判断当前登录人士是否存在
	 * @author: 李赛
	 * @param name
	 * @param pwd
	 * @return
	 */
	User checklogin(String name,String pwd);
	
	/**
	 * @Description:  新增用户
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	int insertUser(User user);

	/**
	 * @Description:根据手机号查询唯一用户 
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	List<User> selectByPhone(User user);
	

	int addLoginlog(String name, String addr, String dateTime);

	/**
	 * 删除方法
	 * @param userid
	 * @return
	 */
	int deleteById(int userid);
	/**
	 * 添加用户
	 * @param user
	 * @return
	 */
	int addUser(User user);
	/**
	 * 修改方法
	 * @param user
	 * @return
	 */
	int updateUser(User user);
	/**
	 * 查询方法
	 * @param user
	 * @return
	 */
	List<User> findUsers(User user);
	
	/**
	 * 查询用户
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	List<User> selectUserInfo(User user);
	
	/**
	 * 校验手机号
	 * @Description:  
	 * @author: 李赛
	 * @param phone
	 * @param name
	 * @return
	 */
	User checkpwdhf(String phone,String name);
	
	/**
	 * 根据手机号修改密码
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	int updateUserByPhone(User user);
	

	User findUserByName(String username);

	User findUserById(int userid);
	
	
	/**
	 * 校验用户名唯一合法性
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	List<User> selectByUsername(User user);

	/**
	 * 查询数据
	 */
	int selectcount();
}
