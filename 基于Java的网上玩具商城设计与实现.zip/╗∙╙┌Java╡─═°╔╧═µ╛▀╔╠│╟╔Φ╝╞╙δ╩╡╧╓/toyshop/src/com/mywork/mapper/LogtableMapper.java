package com.mywork.mapper;

import java.util.List;

import com.mywork.pojo.Loginlog;
import com.mywork.pojo.Logtable;

public interface LogtableMapper {

	int addLogtable(Logtable logtable);

	int findLoginlogTotalCount(String name);

	List<Loginlog> findLoginlog(int startRow, int size, String name);

	int findLogtableTotalCount(String name);

	List<Logtable> findLogtable(int startRow, int size, String name);
	

}
