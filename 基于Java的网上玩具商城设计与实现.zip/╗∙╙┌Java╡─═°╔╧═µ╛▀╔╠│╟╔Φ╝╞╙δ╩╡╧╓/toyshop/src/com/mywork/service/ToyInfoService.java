package com.mywork.service;

import java.util.List;

import com.mywork.pojo.Toyinfo;


public interface ToyInfoService {
	/**
	 * 新增商品
	 * @Description:  
	 * @author: 李赛
	 * @param record
	 * @return
	 */
	 int insertSelective(Toyinfo record);
	 
	 
    /**
     * @Description:  查询所有列表
     * @author: 李赛
     * @return
     */
    List<Toyinfo> selectToyList();

    /**
     * @Description:  查询所有列表
     * @author: 李赛
     * @return
     */
    List<Toyinfo> selectIsDownToyList(Toyinfo record); 
    
    /**
     * @Description:  根据主键查询玩具
     * @author: 李赛
     * @param id
     * @return
     */
    Toyinfo selectByPrimaryKey(Integer id);
    
    /**
     * 根据主键更新
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Toyinfo record);
    
    /**
     * 更新已卖出数量
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    int updateNum(Toyinfo record);
    /**
     * 下架上架商品
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    int updateDown(Toyinfo record);
    
	
	/**
	 * 根据主键删除
	 * @Description:  
	 * @author: 李赛
	 * @param id
	 * @return
	 */
    int deleteByPrimaryKey(Integer id);
    
    /**
     * 根据条件查询
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    List<Toyinfo> selectToyListByRecord(Toyinfo record);
    
    
    /**
     * 校验购物车信息是否过期
     * @Description:  
     * @author: 李赛
     * @param id
     * @return
     */
    Toyinfo checkCartOrderInfo(Integer id);
    
    
    /**
     * 上主页商品
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    int updateIstop(Toyinfo record);
    
    /**
     * 商品数据
     * @Description:  
     * @author: 李赛
     * @return
     */
    int selectToyCount();
}
