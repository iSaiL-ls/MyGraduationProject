package com.mywork.service;

import java.util.List;

import com.mywork.pojo.Evaluate;


public interface EvaluateService {
	
	/**
     * @Description:  更新评价表
     * @author: 李赛
     * @param record
     * @return
     */
    int insertSelective(Evaluate record);
    
    /**
     * 根据主键查询评价
     * @Description:  
     * @author: 李赛
     * @param id
     * @return
     */
    Evaluate selectByPrimaryKey(Integer id);
    
    /**
     * 查询商品评价
     * @Description:  
     * @author: 李赛
     * @param id
     * @return
     */
    List<Evaluate> selectEvaluate(Integer toyid);
    
    /**
     * 删除评价
     * @Description:  
     * @author: 李赛
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);
}
