package com.mywork.service;

import java.util.List;

import com.mywork.pojo.Address;


public interface AddressService {
    /**
     * 新增地址
     * @Description:  
     * @author: 李赛
     * @param record
     * @return
     */
    int insertSelective(Address record);
    
    /**
     * 根据userid查询
     * @Description:  
     * @author: 李赛
     * @param userid
     * @return
     */
    List<Address> selectByUserid(Integer userid);
}
