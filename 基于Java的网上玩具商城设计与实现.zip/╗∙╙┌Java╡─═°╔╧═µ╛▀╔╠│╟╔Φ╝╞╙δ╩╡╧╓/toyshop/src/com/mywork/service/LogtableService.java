package com.mywork.service;

import com.mywork.pojo.Loginlog;
import com.mywork.pojo.Logtable;
import com.mywork.utils.MyPageBean;

public interface LogtableService {

	int addLogtable(Logtable logtable);

	void findLoginlog(MyPageBean<Loginlog> mpb, String name);

	void findLogtable(MyPageBean<Logtable> mpb, String name);
}
