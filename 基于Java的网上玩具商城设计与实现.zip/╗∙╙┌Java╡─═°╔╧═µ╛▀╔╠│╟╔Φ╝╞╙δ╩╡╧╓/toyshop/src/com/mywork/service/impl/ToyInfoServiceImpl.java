package com.mywork.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mywork.mapper.ToyinfoMapper;
import com.mywork.pojo.Toyinfo;
import com.mywork.service.ToyInfoService;

@Service
public class ToyInfoServiceImpl implements ToyInfoService {
	@Autowired
	private ToyinfoMapper toyinfoMapper;

	@Override
	public int insertSelective(Toyinfo record) {
		// TODO Auto-generated method stub
		return toyinfoMapper.insertSelective(record);
	}

	@Override
	public List<Toyinfo> selectToyList() {
		// TODO Auto-generated method stub
		return toyinfoMapper.selectToyList();
	}

	@Override
	public List<Toyinfo> selectIsDownToyList(Toyinfo record) {
		// TODO Auto-generated method stub
		return toyinfoMapper.selectIsDownToyList(record);
	}

	@Override
	public Toyinfo selectByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return toyinfoMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Toyinfo record) {
		// TODO Auto-generated method stub
		return toyinfoMapper.updateByPrimaryKey(record);
	}

	@Override
	public int updateNum(Toyinfo record) {
		// TODO Auto-generated method stub
		return toyinfoMapper.updateNum(record);
	}

	@Override
	public int updateDown(Toyinfo record) {
		// TODO Auto-generated method stub
		return toyinfoMapper.updateDown(record);
	}

	@Override
	public int deleteByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return toyinfoMapper.deleteByPrimaryKey(id);
	}

	@Override
	public List<Toyinfo> selectToyListByRecord(Toyinfo record) {
		// TODO Auto-generated method stub
		return toyinfoMapper.selectToyListByRecord(record);
	}

	@Override
	public Toyinfo checkCartOrderInfo(Integer id) {
		// TODO Auto-generated method stub
		return toyinfoMapper.checkCartOrderInfo(id);
	}

	@Override
	public int updateIstop(Toyinfo record) {
		// TODO Auto-generated method stub
		return toyinfoMapper.updateIstop(record);
	}

	@Override
	public int selectToyCount() {
		// TODO Auto-generated method stub
		return toyinfoMapper.selectToyCount();
	}
	 
}
