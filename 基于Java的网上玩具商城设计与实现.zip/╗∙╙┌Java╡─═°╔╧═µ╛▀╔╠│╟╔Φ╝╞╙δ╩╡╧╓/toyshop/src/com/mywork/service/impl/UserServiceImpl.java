package com.mywork.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mywork.mapper.UserMapper;
import com.mywork.pojo.User;
import com.mywork.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserMapper userMapper;
	
	
	@Override
	public User checklogin(String username, String pwd, String dateTime, String addr) {
		
		//新增日志
		int row = userMapper.addLoginlog(username,addr,dateTime);
		//检验登录人是否存在
		if (row > 0) {
			return userMapper.checklogin(username, pwd);
		}else{
			return null;
		}
	}
	
//注册调用检验是否用户名存在
	@Override
	public int insertUser(User user) {
		// TODO Auto-generated method stub
		
		//校验用户名是否被占用
		List<User> userList = userMapper.selectByUsername(user);
		if(userList.size()>0){
			return 2;
		}
		
		return userMapper.insertUser(user);
	}
	
	
	
	
	@Override
	public int deleteById(Integer userid) {
		return userMapper.deleteById(userid);
	}
	@Override
	public int addUser(User user) {
		return userMapper.addUser(user);
	}

	@Override
	public int updateUser(User user) {
		return userMapper.updateUser(user);
	}

	@Override
	public List<User> findUsers(User user) {
		return userMapper.findUsers(user);
	}


	@Override
	public User findUserByName(String username) {
		return userMapper.findUserByName(username);
	}


	@Override
	public User findUserById(int userid) {
		return userMapper.findUserById(userid);
	}


	@Override
	public List<User> selectByPhone(User user) {
		// TODO Auto-generated method stub
		return userMapper.selectByPhone(user);
	}


	@Override
	public List<User> selectUserInfo(User user) {
		// TODO Auto-generated method stub
		return userMapper.selectUserInfo(user);
	}


	@Override
	public User checkpwdhf(String phone, String name) {
		// TODO Auto-generated method stub
		return userMapper.checkpwdhf(phone, name);
	}


	@Override
	public int updateUserByPhone(User user) {
		// TODO Auto-generated method stub
		return userMapper.updateUserByPhone(user);
	}


	@Override
	public int selectcount() {
		// TODO Auto-generated method stub
		return userMapper.selectcount();
	}







}
