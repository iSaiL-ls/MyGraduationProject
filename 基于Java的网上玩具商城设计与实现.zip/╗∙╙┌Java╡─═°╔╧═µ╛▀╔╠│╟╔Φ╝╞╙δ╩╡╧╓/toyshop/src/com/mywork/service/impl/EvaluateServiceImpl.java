package com.mywork.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mywork.mapper.EvaluateMapper;
import com.mywork.pojo.Evaluate;
import com.mywork.service.EvaluateService;

@Service
public class EvaluateServiceImpl implements EvaluateService {
	@Autowired
	private EvaluateMapper evaluateMapper;
	//更新评论表
	@Override
	public int insertSelective(Evaluate record) {
		evaluateMapper.insertSelective(record);
		Integer id = 0; 
		if(record.getId()>0){
			record.setId(record.getId());
			id = record.getId();
		}
		return id;
	}

	@Override
	public Evaluate selectByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return evaluateMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Evaluate> selectEvaluate(Integer toyid) {
		// TODO Auto-generated method stub
		return evaluateMapper.selectEvaluate(toyid);
	}

	@Override
	public int deleteByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return evaluateMapper.deleteByPrimaryKey(id);
	}

}
