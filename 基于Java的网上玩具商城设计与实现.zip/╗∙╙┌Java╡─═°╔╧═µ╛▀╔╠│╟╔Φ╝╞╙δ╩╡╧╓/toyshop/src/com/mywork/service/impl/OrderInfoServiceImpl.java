package com.mywork.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mywork.mapper.EvaluateMapper;
import com.mywork.mapper.OrderinfoMapper;
import com.mywork.pojo.Orderinfo;
import com.mywork.service.OrderInfoService;

@Service
public class OrderInfoServiceImpl implements OrderInfoService {
	
	@Autowired 
	private OrderinfoMapper orderinfoMapper;
	@Autowired
	private EvaluateMapper evaluateMapper;
	 
	@Override
	public int insertSelective(Orderinfo record) {
		orderinfoMapper.insertSelective(record);
		Integer id = null;
		if(record.getId()!=null){
			id = record.getId();
		}
		return id;
	}

	@Override
	public List<Orderinfo> selectByUserId(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectByUserId(record);
	}

	@Override
	public int updateByPrimaryKeySelective(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	@Transactional
	public int deleteByPrimaryKey(Integer id) {
		//同时删除评价表和订单表
		Orderinfo orderInfo = orderinfoMapper.selectByPrimaryKey(id);
		if(orderInfo.getIsevaluate()==1){
			evaluateMapper.deleteByPrimaryKey(orderInfo.getEvaluateid());
		}
		return orderinfoMapper.deleteByPrimaryKey(id);
	}

	@Override
	public List<Orderinfo> selectcount(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectcount(record);
	}

	@Override
	public List<Orderinfo> selectByUserIdPage(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectByUserIdPage(record);
	}

	@Override
	public List<Orderinfo> selectAllOrderList() {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectAllOrderList();
	}

	@Override
	public List<Orderinfo> selectOrderInfo(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectOrderInfo(record);
	}

	@Override
	public Orderinfo selectByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Orderinfo> selectIsShipList() {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectIsShipList();
	}

	@Override
	public int updateShip(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.updateShip(record);
	}

	@Override
	public List<Orderinfo> selectByStatus(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectByStatus(record);
	}

	@Override
	public List<Orderinfo> selectCart(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectCart(record);
	}

	@Override
	public List<Orderinfo> selectEvaluateInfo(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectEvaluateInfo(record);
	}

	@Override
	public int selectOrderCount() {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectOrderCount();
	}
	 
	@Override
	public int selectOrderCountAll() {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectOrderCountAll();
	}

	@Override
	public List<Orderinfo> selectNotEvaluate(Orderinfo record) {
		// TODO Auto-generated method stub
		return orderinfoMapper.selectNotEvaluate(record);
	}
}
