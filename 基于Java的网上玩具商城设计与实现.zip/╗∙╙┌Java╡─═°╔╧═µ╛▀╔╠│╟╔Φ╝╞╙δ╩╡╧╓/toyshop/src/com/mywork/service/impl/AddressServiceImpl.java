package com.mywork.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mywork.mapper.AddressMapper;
import com.mywork.pojo.Address;
import com.mywork.service.AddressService;

@Service
public class AddressServiceImpl implements AddressService {
	@Autowired
	private AddressMapper addressMapper;
	
	@Override
	public int insertSelective(Address record) {
		addressMapper.insertSelective(record);
		int id = 0;
		if(record.getId()!=null){
			id = record.getId();
		}
		
		return id;
	}

	@Override
	public List<Address> selectByUserid(Integer userid) {
		// TODO Auto-generated method stub
		return addressMapper.selectByUserid(userid);
	}
	
}
