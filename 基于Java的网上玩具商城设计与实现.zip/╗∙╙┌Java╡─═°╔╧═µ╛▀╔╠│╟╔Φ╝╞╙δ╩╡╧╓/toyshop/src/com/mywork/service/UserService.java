package com.mywork.service;

import java.util.List;

import com.mywork.pojo.User;

public interface UserService {
	
	/**
	 * @Description:  校验当前登录人是否存在
	 * @author: 李赛
	 * @param name
	 * @param pwd
	 * @param dateTime
	 * @param addr
	 * @return
	 */
	User checklogin(String username, String pwd, String dateTime, String addr);

	
	/**
	 * @Description:  新增用户
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	int insertUser(User user);
	
	
	
	/**
	 * 根据主键删除
	 * @Description:  
	 * @author: 李赛
	 * @param userid
	 * @return
	 */
	int deleteById(Integer userid);
	
	/**
	 * @Description:根据手机号查询唯一用户 
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	List<User> selectByPhone(User user);

	/**
	 * 查询用户
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	List<User>selectUserInfo(User user);
	
	/**
	 * 校验手机号
	 * @Description:  
	 * @author: 李赛
	 * @param phone
	 * @param name
	 * @return
	 */
	User checkpwdhf(String phone,String name);
	
	/**
	 * 根据手机号修改密码
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	int updateUserByPhone(User user);
	int addUser(User user);

	int updateUser(User user);

	List<User> findUsers(User user);

	User findUserByName(String username);

	User findUserById(int userid);
	
	/**
	 * 查询数据
	 */
	int selectcount();
}
