package com.mywork.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mywork.pojo.Address;
import com.mywork.pojo.User;
import com.mywork.service.AddressService;
import com.mywork.service.OrderInfoService;
import com.mywork.service.ToyInfoService;
import com.mywork.service.UserService;

/**
 * 地址管理controller
 * @Description:  
 * @author: 李赛
 */
@Controller
public class AddressConroller {
	@Autowired
	private ToyInfoService toyInfoService;
	@Autowired
	private OrderInfoService orderInfoService;
	@Autowired
	private AddressService addressService;
	@Autowired
	UserService userService;
	
	/**
	 * @Description: 个人信息首页 
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("address")
	public String address(HttpServletRequest request) {
		// 通过session中的用户去拿到user的id
		User user = (User) request.getSession().getAttribute("currentUser");
		if(user==null){
			return "login";
		}
		//查询用户的基本信息
		user = userService.findUserById(user.getUserid());
		request.setAttribute("user",user);
		//查询用户的地址
		List<Address> addressList = addressService.selectByUserid(user.getUserid());
		request.setAttribute("addressList",addressList);
		return "address";
	}
	
	
	/**
	 * @Description:商品列表  
	 * @author: 李赛
	 * @param req
	 * @return
	 */
	@RequestMapping("saveAddress")
	public String saveAddress(Address address,HttpServletRequest request){
		// 通过session中的用户去拿到user的id
		User u = (User) request.getSession().getAttribute("currentUser");
		if(u==null){
			return "login";
		}
		//userid
		address.setUserid(u.getUserid());
		addressService.insertSelective(address);
		return "returnAddress";
	}
	
	
}
