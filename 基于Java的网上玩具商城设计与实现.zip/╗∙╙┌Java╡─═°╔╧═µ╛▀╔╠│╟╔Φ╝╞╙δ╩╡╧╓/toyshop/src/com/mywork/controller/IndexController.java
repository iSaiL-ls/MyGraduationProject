package com.mywork.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mywork.pojo.Evaluate;
import com.mywork.pojo.Menu;
import com.mywork.pojo.Toyinfo;
import com.mywork.pojo.User;
import com.mywork.service.EvaluateService;
import com.mywork.service.MenuService;
import com.mywork.service.ToyInfoService;

/**
 * 主页面controller
 * @Description:  
 * @author: 李赛
 */
@Controller
public class IndexController {

	@Autowired
	MenuService menuService;
	@Autowired
	private ToyInfoService toyInfoService;
	@Autowired
	private EvaluateService evaluateService;
	/**
	 * @Description:  后台管理员跳转页面
	 * @author: 李赛
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping("indexadmin")
	public String indexadmin(User user, HttpServletRequest request) {
		// 通过session中的用户去拿到user的id
		User u = (User) request.getSession().getAttribute("currentUser");
		if(u!=null){
			if(u.getRoleid()==2){
				return "login";
			}
		}
		
		// 通过用户ID取得菜单列表.
		List<Menu> menus = menuService.findMenuByUserId(u.getUserid());
		// 通过request存储menus.
		request.setAttribute("menus", menus);
		return "indexadmin";
	}
	
	
	/**
	 * @Description:  后台管理员跳转页面
	 * @author: 李赛
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping("index")
	public String index(User user, HttpServletRequest request) {
		// 通过session中的用户去拿到user的id
		User u = (User) request.getSession().getAttribute("currentUser");
		if(u!=null){
			request.setAttribute("username", u.getUsername());
			if(u.getRoleid()==1){
				return "adminlogin";
			}
			
		}else{
			request.setAttribute("username", 0);
		}
		//获取商品类型
		String toytype = request.getParameter("toytype");
		//获取商品名称
		String toyname = request.getParameter("toyname");
		Toyinfo record = new Toyinfo();
		//商品类型
		if(!com.alibaba.druid.util.StringUtils.isEmpty(toytype)){
			record.setToytype(Integer.valueOf(toytype));
			request.setAttribute("typezs", 0);
			request.setAttribute("toytype", toytype);
		}else{
			request.setAttribute("toytype", 0);
			request.setAttribute("typezs", 1);
		}
		//商品名称 
		if(!com.alibaba.druid.util.StringUtils.isEmpty(toyname)){
			record.setToyname(toyname);
			request.setAttribute("toynameint", 0);
			request.setAttribute("toyname", toyname);
		}else{
			request.setAttribute("toynameint", 1);
			
		}
		
		//根据下拉来查询
		//判断是哪个下拉
		//根据什么来筛选
		String seltype = request.getParameter("seltype");
		if(!com.alibaba.druid.util.StringUtils.isEmpty(seltype)){
			request.setAttribute("seltype", Integer.valueOf(seltype));
			if(Integer.valueOf(seltype)==1){
				record.setIstop(0);
			}
			if(Integer.valueOf(seltype)==2){
				record.setNum(Integer.valueOf(seltype));
			}
			if(Integer.valueOf(seltype)==3){
				record.setNum(Integer.valueOf(seltype));
			}
			if(Integer.valueOf(seltype)==4){
				record.setNum(Integer.valueOf(seltype));
			}
			if(Integer.valueOf(seltype)==5){
				record.setNum(Integer.valueOf(seltype));
			}
		}else{
			request.setAttribute("seltype", 0);
		}
		
		//查询所有商品信息
		List<Toyinfo> toyList = toyInfoService.selectIsDownToyList(record);
		if(toyList.size()>0){
			request.setAttribute("toyList", toyList);
		}
		return "index";
	}
	
	/**
	 * 
	 * @Description:  选择商品跳转
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("proDetail")
	public String proDetail(HttpServletRequest request) {
		SimpleDateFormat fo = new SimpleDateFormat("yyyy-MM-dd");
		//获取玩具id
		int toyid = Integer.valueOf(request.getParameter("id"));
		//查询玩具的基本信息
		Toyinfo toyInfo = toyInfoService.selectByPrimaryKey(toyid);
		Integer totalnum = toyInfo.getTotalnum();
		Integer num = toyInfo.getNum();
		toyInfo.setBz1(totalnum-num);
		request.setAttribute("toyInfo", toyInfo);
		//查询该商品的评价
		List<Evaluate> evaluateList = evaluateService.selectEvaluate(toyid);
		for (Evaluate evaluate : evaluateList) {
			evaluate.setBz3(fo.format(evaluate.getBz5()));
			String phoneNumber = evaluate.getBz6().substring(0, 3) + "****" + evaluate.getBz6().substring(7, evaluate.getBz6().length());
			evaluate.setBz6(phoneNumber);
		}
		request.setAttribute("evaluateList", evaluateList);
		
		//查询猜你喜欢，根据类型
		Toyinfo toytype = new Toyinfo();
		toytype.setToytype(toyInfo.getToytype());
		List<Toyinfo> toyList = new ArrayList<Toyinfo>();
		List<Toyinfo> toyListq = toyInfoService.selectIsDownToyList(toytype);
		for (Toyinfo toyinfo2 : toyListq) {
			if(toyinfo2.getId()!=toyid){
				toyList.add(toyinfo2);
			}
		}
		//通过session里拿到user放到前端
		User u = (User) request.getSession().getAttribute("currentUser");
		request.setAttribute("toyList", toyList);
		request.setAttribute("username", u);
		
		return "proDetail";
	}
	
	/**
	 * 
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("showMenu")
	public String showMenu(HttpServletRequest request) {
		// 通过用户ID取得菜单列表.
		List<Menu> menus = menuService.showMenu();
		// 通过request存储menus.
		request.setAttribute("menus", menus);
		return "addRole";
	}
}
