package com.mywork.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mywork.common.AjaxResult;
import com.mywork.common.BaseController;
import com.mywork.pojo.User;
import com.mywork.service.UserService;

/**
 * @Description: 注册controller
 * @author: 李赛
 */
@Controller
public class RegisterController extends BaseController{
	@Autowired
	UserService userService;
	
	/**
	 * @Description:  注册接口
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	@RequestMapping("register")
	@ResponseBody
	public AjaxResult addUser(User user) {
		if(user.getUsername() == null || user.getUserpwd() == null || user.getPhone()==null){
			return error("用户名密码为空!");
		}
		//普通用户
		user.setRoleid(2);
		int result = userService.insertUser(user);
		if (result == 1) {
			 return success("注册成功！");
		}
		if (result == 2) {
			 return error("用户名已被注册，请勿重复注册！");
		}
		
		return error("注册失败！");
	}

}
