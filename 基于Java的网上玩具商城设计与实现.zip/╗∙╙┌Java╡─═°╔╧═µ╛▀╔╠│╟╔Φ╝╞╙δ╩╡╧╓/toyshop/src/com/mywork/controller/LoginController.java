package com.mywork.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mywork.common.AjaxResult;
import com.mywork.common.BaseController;
import com.mywork.pojo.User;
import com.mywork.service.RoleService;
import com.mywork.service.UserService;

/**
 * @Description: 登录controller
 * @author: 李赛
 */
@Controller
public class LoginController extends BaseController{
	@Autowired
	UserService userService;
	@Autowired
	RoleService roleService;

	/**
	 * @Description: 登录接口
	 * @author: 李赛
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping("userLogin")
	@ResponseBody
	public AjaxResult login(User user, HttpServletRequest request) {
		// 获取登录数据
		String addr = request.getRemoteAddr();
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateTime = sdf.format(date);
		String password = user.getUserpwd();
		User u = userService
				.checklogin(user.getUsername(), password, dateTime, addr);
		// 取得到对象之后,将用户存入session 中. 为了以后可能会使用到登录用户的数据.
		request.getSession().setAttribute("currentUser", u);
		if (u == null) {
			return error("用户名不存在或密码错误！");
		} 
		if(u.getRoleid()==1){
			return success("okadmin");
		}else{
			return success("ok");
		}
	}
	
	/**
	 * 校验手机号合法性
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping("checkpwdhf")
	@ResponseBody
	public AjaxResult checkpwdhf(User user, HttpServletRequest request) {
		String phone = user.getPhone();
		String username = user.getUsername();
		User u = userService.checkpwdhf(phone, username);
		if (u == null) {
			return error("用户名与预留手机号有误！");
		} 
		 
		return success();
	}
	
	

	/**
	 * @Description:  退出登录
	 * @author: 李赛
	 * @param req
	 * @param resp
	 * @return
	 */
	@RequestMapping("login")
	public String adminlogin(HttpServletRequest req, HttpServletResponse resp) {
		return "adminlogin";
	}

	/**
	 * @Description:  登录
	 * @author: 李赛
	 * @param req
	 * @param resp
	 * @return
	 */
	@RequestMapping("custlogin")
	public String userlogin(HttpServletRequest req, HttpServletResponse resp) {
		return "login";
	}
	
	
	/**
	 * @Description:  退出登录
	 * @author: 李赛
	 * @param req
	 * @param resp
	 * @return
	 */
	@RequestMapping("logout")
	public String logout(HttpServletRequest req, HttpServletResponse resp) {
		req.getSession().invalidate();
		return "login";
	}

	
	/**
	 * @Description:  退出登录
	 * @author: 李赛
	 * @param req
	 * @param resp
	 * @return
	 */
	@RequestMapping("adminlogout")
	public String adminlogout(HttpServletRequest req, HttpServletResponse resp) {
		req.getSession().invalidate();
		return "adminlogin";
	}
	
}
