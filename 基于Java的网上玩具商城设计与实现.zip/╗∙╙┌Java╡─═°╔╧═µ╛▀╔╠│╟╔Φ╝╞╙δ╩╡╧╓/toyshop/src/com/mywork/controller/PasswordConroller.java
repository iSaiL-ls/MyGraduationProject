package com.mywork.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mywork.common.AjaxResult;
import com.mywork.common.AjaxResult.Type;
import com.mywork.common.BaseController;
import com.mywork.pojo.User;
import com.mywork.service.OrderInfoService;
import com.mywork.service.ToyInfoService;
import com.mywork.service.UserService;

/**
 * 修改密码controller
 * @Description:  
 * @author: 李赛
 */
@Controller
public class PasswordConroller extends BaseController{
	@Autowired
	private ToyInfoService toyInfoService;
	@Autowired
	UserService userService;
	@Autowired
	private OrderInfoService orderInfoService;
	 
	
	/**
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("remima")
	public String remima(HttpServletRequest request) {
		// 通过session中的用户去拿到user的id
		User user = (User) request.getSession().getAttribute("currentUser");
		user = userService.findUserById(user.getUserid());
		request.setAttribute("user",user);
		return "remima";
	}
	
	
	/**
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("checkpwd")
	@ResponseBody
	public AjaxResult checkpwd(User user,HttpServletRequest request) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateTime = sdf.format(date);
		User u = userService
				.checklogin(user.getUsername(), user.getUserpwd(), dateTime, "修改密码校验");
		if(u==null){
			return error(Type.ERROR, "密码错误！");
		}
		return success();
	}
	
	
	/**
	 * @Description:  个人中心修改密码
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("updatePwd")
	public String updatePwd(User user,HttpServletRequest request) {
		user.setUserpwd(user.getNewuserpwd());
		userService.updateUser(user);
		request.getSession().invalidate();
		return "login";
	}
	
	/**
	 * @Description:  找回密码
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("updatePwdByPhone")
	public String updatePwdByPhone(User user,HttpServletRequest request) {
		user.setUserpwd(user.getNewuserpwd());
		userService.updateUserByPhone(user);
		request.getSession().invalidate();
		return "login";
	}
}
