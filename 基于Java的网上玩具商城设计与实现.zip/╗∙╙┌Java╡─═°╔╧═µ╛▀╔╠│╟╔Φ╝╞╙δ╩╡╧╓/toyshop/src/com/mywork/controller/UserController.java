package com.mywork.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.druid.util.StringUtils;
import com.google.gson.Gson;
import com.mywork.common.AjaxResult;
import com.mywork.common.BaseController;
import com.mywork.pojo.Role;
import com.mywork.pojo.User;
import com.mywork.service.RoleService;
import com.mywork.service.UserService;

@Controller
public class UserController extends BaseController{
	@Autowired
	UserService userService;
	@Autowired
	RoleService roleService;
	
	/**
	 * 新增用户
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	@RequestMapping("addUser")
	public String addUser(User user) {
		if(user.getUsername() == null){
			return "adduser";
		}
		String realname="tx.png";
		user.setRealname(realname);
		int result = userService.addUser(user);
		if (result > 0) {
			return "returnadminListUser";
		}
		return "error";
	}
	
	/**
	 * 检验用户
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	@RequestMapping("ckeckUser")
	@ResponseBody
	public AjaxResult ckeckUser(User user) {
		//以手机为索引
		//List<User> userList = userService.selectByPhone(user);
		//以用户名为索引
		 User userList = userService.findUserByName(user.getUsername());
		if(userList!=null){
			return error("用户名已被注册！");
		}
		return success();
	}
	
	
	/**
	 * 删除
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	@RequestMapping("deleteById")
	public String deleteById(User user) {

		if (userService.deleteById(user.getUserid()) > 0) {
			return "redirect:/ findUsers";
		} else {
			return "error";
		}
	}

	/**
	 * 查询用户列表
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("findUsers")
	public String findUsers(HttpServletRequest request) {
		String username = request.getParameter("username")==""?null:request.getParameter("username");
		String identity = request.getParameter("identity")==""?null:request.getParameter("identity");
		String phone = request.getParameter("phone")==""?null:request.getParameter("phone");
		User user = new User();
		user.setUsername(username);
		user.setIdentity(identity);
		user.setPhone(phone);
		// 接收过来的是前台的数据，放在user对象里。传给service层 与service层中的数据库做对比
		List<User> users = new ArrayList<User>();
		List<User> users2 = userService.findUsers(user);
		for(User u : users2){
			Role r = roleService.getRoleById(u.getRoleid());
			u.setRole(r);
			if(u.getRoleid()!=1){
				users.add(u);
			}
		}
		// 把查询到的数据用来遍历
		request.setAttribute("users", users);
		return "userlist";
	}
	
	/**
	 * 修改用户信息
	 * @Description:  
	 * @author: 李赛
	 * @param req
	 * @return
	 */
	@RequestMapping("preUpdateUser")
	public String preUpdate(HttpServletRequest req) {
		int userid = Integer.parseInt(req.getParameter("userid"));
		User user = userService.findUserById(userid);
		if (user != null) {
			req.setAttribute("user", user);
			return "updateUser";
		}
		return "error";
	}
	
	/**
	 * 修改用户信息
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @return
	 */
	@RequestMapping("userUpdate")
	public String userUpdate(User user){
		int result = userService.updateUser(user);
		//比对所有的用户id不重复即可
		if (result >0) {
			return "returnadminListUser";
		}
		return "error";
	
	}
	
	
	/**
	 * 查询用户
	 * @Description:  
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("searchCust")
	public String findCust() {
		return "searchCust";
	}
	
	/**
	 * 查询用户
	 * @Description:  
	 * @author: 李赛
	 * @param req
	 * @return
	 */
	@RequestMapping("findCusts")
	@ResponseBody
	public String findCusts(HttpServletRequest req) {
		
		String name = req.getParameter("name");
		String identity = req.getParameter("identity");
		String phone = req.getParameter("phone");
		User user = new User();
		if(!StringUtils.isEmpty(name)){
			user.setUsername(name);
		}
		if(!StringUtils.isEmpty(identity)){
			user.setIdentity(identity);
		}
		if(!StringUtils.isEmpty(phone)){
			user.setPhone(phone);
		}
		
		List<User> listUser = new ArrayList<User>();
		// 从业务层拿到数据
		List<User> list = userService.selectUserInfo(user);
		for (User user2 : list) {
			if(user2.getRoleid()!=1){
				listUser.add(user2);
			}
		}
		// 将数据转换成json
		Gson gson = new Gson();
		// 使用gson将集合转换成json串
		String json = gson.toJson(listUser);
		return json;
	}
	
	/**
	 * 删除用户
	 * @Description:  
	 * @author: 李赛
	 * @param custId
	 * @param request
	 * @return
	 */
	@RequestMapping("deleteCustomer")
	public String deleteCustomer(int custId, HttpServletRequest request) {
		
		if (userService.deleteById(custId)> 0) {
			return "ok";
		} else {
			return "error";
		}
	}
	
	
	/**
	 * 更新数据
	 * @Description:  
	 * @author: 李赛
	 * @param customer
	 * @param request
	 * @return
	 */
	@RequestMapping("updateCustomer")
	public String updateCustomer(HttpServletRequest request) {
		int custId = Integer.parseInt(request.getParameter("custId"));
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String identity = request.getParameter("identity");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		User user = new User();
		user.setUserid(custId);
		user.setUserpwd(pwd);
		user.setUsername(name);
		user.setIdentity(identity);
		user.setAddress(address);
		user.setPhone(phone);
		user.setRoleid(2);
		if (userService.updateUser(user) > 0) {
			return "list";
		} else {
			return "error";
		}
	}
	
	/**
	 * 查询下拉
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("preAdduserData")
	@ResponseBody
	public String preAdduserData(HttpServletRequest request) {
		List<Role> roles = roleService.findAllRole();
		Gson gson = new Gson();
		String json = gson.toJson(roles);
		return json;
	}

}
