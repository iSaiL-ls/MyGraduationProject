package com.mywork.controller;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.druid.util.StringUtils;
import com.mywork.common.AjaxResult;
import com.mywork.common.BaseController;
import com.mywork.pojo.Evaluate;
import com.mywork.pojo.Orderinfo;
import com.mywork.pojo.Toyinfo;
import com.mywork.pojo.User;
import com.mywork.service.EvaluateService;
import com.mywork.service.OrderInfoService;
import com.mywork.service.ToyInfoService;
import com.mywork.service.UserService;

/**
 * 订单列表controller
 * @Description:  
 * @author: 李赛
 */
@Controller
public class OrderController extends BaseController{

	@Autowired
	private ToyInfoService toyInfoService;
	@Autowired
	private OrderInfoService orderInfoService;
	@Autowired
	private EvaluateService evaluateService;
	@Autowired
	UserService userService;
	/**
	 * 跳转支付页面
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping("orderInfo")
	public String orderInfo(HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("currentUser");
		if(user==null){
			return "login";
		}
		//商品id
		int toyid = Integer.valueOf(request.getParameter("toyid"));
		//商品订单
		int orderid = Integer.valueOf(request.getParameter("id"));
		//购买数量
		int buynum = Integer.valueOf(request.getParameter("buynum"));
		//支付方式
		int paytype = Integer.valueOf(request.getParameter("paytype"));
		
		//查询玩具的基本信息
		Toyinfo toyInfo = toyInfoService.selectByPrimaryKey(toyid);
		//单价
		Double price = toyInfo.getPrice();
		BigDecimal bprice = new BigDecimal(price);  
		double bpriced =bprice.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue(); 
		//总价
		double totalprice = bpriced*buynum;
		BigDecimal cprice = new BigDecimal(totalprice);  
		double cpriced =cprice.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue(); 
		toyInfo.setTotalprice(cpriced);
		//购买数量
		toyInfo.setBuynum(buynum);
		// 通过session中的用户去拿到user的id
		user = userService.findUserById(user.getUserid());
		request.setAttribute("user",user);
		request.setAttribute("toyInfo", toyInfo);
		request.setAttribute("paytype", paytype);
		request.setAttribute("orderid", orderid);
		return "order";
	}
	
	
	
	/**
	 * 多商品购买跳转支付页面验证
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping("checkOrderInfoCart")
	@ResponseBody
	public AjaxResult checkOrderInfoCart(HttpServletRequest request) {
		//商品订单
		String orderid = request.getParameter("id");
		//返回
		StringBuffer str = new StringBuffer();
		String[] orderidsz =null;
		if(!StringUtils.isEmpty(orderid)){
			orderidsz = orderid.substring(0,orderid.length()-1).split(",");
			for (String orderids : orderidsz) {
				Orderinfo orderInfo = orderInfoService.selectByPrimaryKey(Integer.valueOf(orderids));
				Toyinfo toyInfo = toyInfoService.checkCartOrderInfo(orderInfo.getToyid());
				if(toyInfo==null){
					str.append(orderInfo.getToyname()+"、");
				}
			}
		}
		
		if(!StringUtils.isEmpty(str)){
			return error("您好，商品："+str.substring(0, str.length()-1)+"信息已过期，请重新选择！");
		}
		return success();
	}
	
 
	
	/**
	 * 多商品购买跳转支付页面
	 * @Description:  
	 * @author: 李赛
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping("orderInfoByCart")
	public String orderInfoByCart(HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute("currentUser");
		if(user==null){
			return "login";
		}
		//支付方式
		//int paytype = Integer.valueOf(request.getParameter("paytype"));
		List<Orderinfo> orderInfoList  = new ArrayList<Orderinfo>();
		//传递的订单号
		String orderidcd = "";
		//商品订单
		String orderid = request.getParameter("id");
		Double dtotalprice = 0.00;
		Double totalprice = 0.00;
		String[] orderidsz =null;
		if(!StringUtils.isEmpty(orderid)){
			orderidsz = orderid.substring(0,orderid.length()-1).split(",");
			for (String orderids : orderidsz) {
				Orderinfo orderInfo = orderInfoService.selectByPrimaryKey(Integer.valueOf(orderids));
				dtotalprice = orderInfo.getTotalprice();
				totalprice+=dtotalprice;
				orderInfoList.add(orderInfo);
				orderidcd+=orderids+",";
			}
		}
		
		//总价
		BigDecimal bprice = new BigDecimal(totalprice); 
		double cpriced =bprice.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue(); 
		
		// 通过session中的用户去拿到user的id
		user = userService.findUserById(user.getUserid());
		request.setAttribute("user",user);
		request.setAttribute("cpriced", cpriced);
		request.setAttribute("orderidsz", orderidcd);
		request.setAttribute("orderInfoList", orderInfoList);
		return "orderCart";
	}
	
 
	
	/**
	 * 购物车
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("cart")
	public String cart(HttpServletRequest request) {
		//用户id
		User user = (User) request.getSession().getAttribute("currentUser");
		if(user==null){
			return  "login";
		}
		Orderinfo orderinfo = new Orderinfo();
		//用户id
		orderinfo.setUserid(user.getUserid());
		//购物车
		orderinfo.setBz1(2);
		List<Orderinfo> orderList = orderInfoService.selectCart(orderinfo);
		request.setAttribute("orderList", orderList);
		return "cart";
	}
	
	
	
	/**
	 * @Description:添加购物车  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("orderCartInfo")
	public String orderCartInfo(HttpServletRequest request) {
		//用户id
		User user = (User) request.getSession().getAttribute("currentUser");
		if(user==null){
			return "login";
		}
		
		Orderinfo orderinfo = new Orderinfo();
		//商品id
		int id = Integer.valueOf(request.getParameter("id"));
		//购买数量
		int buynum = Integer.valueOf(request.getParameter("buynum"));
		//查询玩具的基本信息
		Toyinfo toyInfo = toyInfoService.selectByPrimaryKey(id);
		//单价
		Double price = toyInfo.getPrice();
		BigDecimal bprice = new BigDecimal(price);  
		double bpriced =bprice.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue(); 
		//总价
		double totalprice = bpriced*buynum;
		BigDecimal cprice = new BigDecimal(totalprice);  
		double cpriced =cprice.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue(); 
		//购买数量
		toyInfo.setBuynum(buynum);
		//商户订单号，商户网站订单系统中唯一订单号，必填
        //long currtime = System.currentTimeMillis();
		//订单编号
		//orderinfo.setToynoid(String.valueOf(currtime));
		//用户id
		orderinfo.setUserid(user.getUserid());
		//用户名称
		orderinfo.setUsername(user.getUsername());
		//商品id
		orderinfo.setToyid(id);
		//商品名称
		orderinfo.setToyname(toyInfo.getToyname());
		//数量
		orderinfo.setBuynum(buynum);
		//总金额
		orderinfo.setTotalprice(cpriced);
		//date
		Date date = new Date();
		orderinfo.setBuydate(date);
		//是否评价
		orderinfo.setIsevaluate(2);
		//购物车
		orderinfo.setBz1(2);
		//类型
		orderinfo.setBz2(toyInfo.getToytype());
		//单价
		orderinfo.setPrice(bpriced);
		orderinfo.setImg(toyInfo.getImg());
		orderInfoService.insertSelective(orderinfo);
		return "returnCart";
	}
  
	
	/**
	 * 支付成功后返回按钮/查看订单
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("orderReturn")
	public String orderReturn(HttpServletRequest request){
		String no = request.getParameter("out_trade_no");
		//用户id
		User user = (User) request.getSession().getAttribute("currentUser");
		// 通过session中的用户去拿到user的id
		user = userService.findUserById(user.getUserid());
		
		if(!StringUtils.isEmpty(no)){
			//截取支付宝沙箱返回数据
			int index = no.indexOf("|");
			String toynoid = no.substring(0, index);
			String noid = no.substring(index+1,no.length());
			String[] orderid = noid.substring(0, noid.length()-1).split(",");
			for (String string : orderid) {
				Orderinfo orderinfo = orderInfoService.selectByPrimaryKey(Integer.valueOf(string));
				//存入订单号
				orderinfo.setToynoid(toynoid);
				//改变订单状态
				orderinfo.setBz1(1);
				//收货人姓名
				orderinfo.setBz3(user.getPosition());
				//收货人电话
				orderinfo.setBz4(user.getIdentity());
				//收货地址
				orderinfo.setBz5(user.getAddress());
		    	orderInfoService.updateByPrimaryKeySelective(orderinfo);
		    	  //更新商品卖出数量
		        Toyinfo toy = new Toyinfo();
		        //商品id
		        toy.setId(orderinfo.getToyid());
		        //卖出数量
		        toy.setNum(orderinfo.getBuynum());
		        toyInfoService.updateNum(toy);
			}
			
		}
		
		Orderinfo record = new Orderinfo();
		record.setUserid(user.getUserid());
		
		String isevaluate = request.getParameter("isevaluate");
		if(!StringUtils.isEmpty(isevaluate)){
			record.setIsevaluate(2);
		}
		//订单状态
		String isbz = request.getParameter("isbz");
		if(!StringUtils.isEmpty(isbz)){
			record.setBz1(Integer.valueOf(isbz));
		}
		
		//查询当前用户下的所有订单
		List<Orderinfo> ordercount =  orderInfoService.selectcount(record);
		String pagenum = request.getParameter("pagenum");
		int pagenumint = 1;
		if(!StringUtils.isEmpty(pagenum)){
			pagenumint = Integer.valueOf(pagenum);
		}
		
		//查询的第几页
		int num = (pagenumint-1)*2;
		record.setPageNum(num);
		
		//订单状态
		if(!StringUtils.isEmpty(isbz)){
			record.setBz1(Integer.valueOf(isbz));
		}else{
			//已支付
			record.setBz1(null);
		}
		
		//查询当前用户下的所有订单
		String toyname = request.getParameter("toyname");
		if(!StringUtils.isEmpty(toyname)){
			record.setToyname(toyname);
		}
		List<Orderinfo> orderList =  orderInfoService.selectByUserIdPage(record);
		SimpleDateFormat fo = new SimpleDateFormat("yyyy-MM-dd");
		for (Orderinfo orderinfo : orderList) {
			orderinfo.setBz3(fo.format(orderinfo.getBuydate()));
		}
		
		request.setAttribute("user",user);
		request.setAttribute("orderList", orderList);
		request.setAttribute("pagenumint", pagenumint);
		request.setAttribute("isevaluate", isevaluate);
		request.setAttribute("isbz", isbz);
		request.setAttribute("toyname", toyname);
		
		
		int cont = ordercount.size()/2;
		if(ordercount.size()/2!=0){
			cont+=1;
		}
		request.setAttribute("count",cont );
		return "myorderq";
	}
	
	/**
	 * 
	 * @Description: 查询评价的商品 
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("evaluated")
	public String notevaluated(HttpServletRequest request){
		//用户id
		User user = (User) request.getSession().getAttribute("currentUser");
		Orderinfo record = new Orderinfo();
		//当前用户
		record.setUserid(user.getUserid());
		//未评价
		record.setIsevaluate(2);
		//订单完成
		record.setBz1(4);
		//查询当前用户下的所有订单
		List<Orderinfo> notorderList =  orderInfoService.selectNotEvaluate(record);
		SimpleDateFormat fo = new SimpleDateFormat("yyyy-MM-dd");
		for (Orderinfo orderinfo : notorderList) {
			orderinfo.setBz3(fo.format(orderinfo.getBuydate()));
		}
		request.setAttribute("notorderList", notorderList);
		
		//已评价
		record.setIsevaluate(1);
		List<Orderinfo> alreadyorderList =  orderInfoService.selectNotEvaluate(record);
		for (Orderinfo orderinfo1 : alreadyorderList) {
			orderinfo1.setBz3(fo.format(orderinfo1.getBuydate()));
			//根据评价表主键查询
			Integer evaluateid = orderinfo1.getEvaluateid();
			if(evaluateid!=null && evaluateid!=0){
				Evaluate evaluate = evaluateService.selectByPrimaryKey(evaluateid);
				//打分
				orderinfo1.setScoring(evaluate.getScoring());
				//评价
				orderinfo1.setEvaluate(evaluate.getEvaluate());
			}
		}
		// 通过session中的用户去拿到user的id
		user = userService.findUserById(user.getUserid());
		request.setAttribute("user",user);
		request.setAttribute("alreadyorderList", alreadyorderList);
		return "myprod";
	}
	
	
	/**
	 * @Description: 保存评价
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("saveEvaluated")
	public String saveEvaluated(Evaluate evaluate,HttpServletRequest request){
		//更新评价表
		int id = evaluateService.insertSelective(evaluate);
		//更新订单表
		Integer orderid = evaluate.getOrderid();
		Orderinfo orderInfo = new Orderinfo();
		orderInfo.setIsevaluate(1);
		orderInfo.setId(orderid);
		orderInfo.setEvaluateid(id);
		orderInfoService.updateByPrimaryKeySelective(orderInfo);
		return "returnOrederList";
	}
	
	
	/**
	 * 查看评价 
	 * @Description:  
	 * @author: 李赛
	 * @param id
	 * @param request
	 * @return
	 */
	@RequestMapping("queryEvaluated")
	@ResponseBody
	public Evaluate queryEvaluated(int id,HttpServletRequest request){
		Evaluate evaluated = evaluateService.selectByPrimaryKey(id);
		return evaluated;
	}
	
	/**
	 * 删除购物车商品
	 * @Description:  
	 * @author: 李赛
	 * @param id
	 * @param request
	 * @return
	 */
	@RequestMapping("orderInfoDel")
	public String orderInfoDel(HttpServletRequest request){
		//商品订单
		int orderid = Integer.valueOf(request.getParameter("id"));
		orderInfoService.deleteByPrimaryKey(orderid);
		return "returnCart";
	}
	
	/**
	 * @Description: 订单详情
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("orderxq")
	public String orderxq(HttpServletRequest request){
		//商品订单
		User user = (User) request.getSession().getAttribute("currentUser");
		
		int orderid = Integer.valueOf(request.getParameter("orderid"));
		Orderinfo orderInfo = orderInfoService.selectByPrimaryKey(orderid);
		request.setAttribute("orderInfo",orderInfo);
		request.setAttribute("user",user);
		return "orderxq";
	}
	
	
	/**
	 * 评论管理
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("selectEvaluate")
	public String selectEvaluate(HttpServletRequest request){
		SimpleDateFormat fo = new SimpleDateFormat("yyyy-MM-dd");
		Orderinfo orderInfo = new Orderinfo();
		String noid = request.getParameter("noid");
		if(!StringUtils.isEmpty(noid)){
			orderInfo.setToynoid(noid);
		}
		String toyname =  request.getParameter("toyname");
		if(!StringUtils.isEmpty(toyname)){
			orderInfo.setToyname(toyname);
		}
		
		List<Orderinfo> orderList = orderInfoService.selectEvaluateInfo(orderInfo);
		for (Orderinfo orderinfo2 : orderList) {
			orderinfo2.setBz3(fo.format(orderinfo2.getBuydate()));
		}
		
		request.setAttribute("orderList",orderList);
		return "listEvaluate";
	}
	
	/**
	 * 删除评论
	 * @param request
	 * @return
	 */
	@RequestMapping("deleteEval")
	@Transactional
	public String deleteEval(HttpServletRequest request){
		String orderid = request.getParameter("orderid");
		Orderinfo orderInfo = orderInfoService.selectByPrimaryKey(Integer.valueOf(orderid));
		evaluateService.deleteByPrimaryKey(orderInfo.getEvaluateid());
		orderInfo.setEvaluateid(0);
		orderInfoService.updateByPrimaryKeySelective(orderInfo);
		return "returnListEval";
	}
	
	
}
