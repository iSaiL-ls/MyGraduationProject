package com.mywork.controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.druid.util.StringUtils;
import com.google.gson.Gson;
import com.mywork.pojo.Orderinfo;
import com.mywork.pojo.Toyinfo;
import com.mywork.service.OrderInfoService;
import com.mywork.service.ToyInfoService;
import com.mywork.service.UserService;

/**
 * 后台管理controller
 * @Description:  
 * @author: 李赛
 */
@Controller
public class AdminConroller {
	@Autowired
	private ToyInfoService toyInfoService;
	@Autowired
	private OrderInfoService orderInfoService;
	
	@Autowired
	UserService userService;
	
	/**
	 * @Description: 新增商品 
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("addToy")
	public String addCar(){
		return "addToy";
	}
	
	
	/**
	 * @Description: 主页
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("mainlist")
	public String mainlist(HttpServletRequest req){
		//用户数
		int userCount = userService.selectcount();
		//销量
		int orderCount = orderInfoService.selectOrderCount();
		//订单数
		int orderCountAll = orderInfoService.selectOrderCountAll();
		//商品数
		int toyCount = toyInfoService.selectToyCount();
		
		req.setAttribute("userCount", userCount);
		req.setAttribute("orderCount", orderCount);
		req.setAttribute("orderCountAll", orderCountAll);
		req.setAttribute("toyCount", toyCount);
		
		return "mainlist";
	}
	/**
	 * @Description:商品列表  
	 * @author: 李赛
	 * @param req
	 * @return
	 */
	@RequestMapping("findToyHandler")
	public String findCar(HttpServletRequest req){
		String toyname = req.getParameter("toyname")==""?null:req.getParameter("toyname");
		String toytype = req.getParameter("toytype")==""?null:req.getParameter("toytype");
		String isdown = req.getParameter("isdown")==""?null:req.getParameter("isdown");
		
		Toyinfo toyinfo = new Toyinfo();
		toyinfo.setToyname(toyname);
		if(!StringUtils.isEmpty(toytype)){
			toyinfo.setToytype(Integer.valueOf(toytype));
		}
		if(!StringUtils.isEmpty(isdown)){
			toyinfo.setIsdown(Integer.valueOf(isdown));
		}
		
		//查询所有商品信息
		List<Toyinfo> toyList = toyInfoService.selectToyListByRecord(toyinfo);
		if(toyList.size()>0){
			req.setAttribute("toyList", toyList);
		}
		return "listToy";
	}
	
	/**
	 * 保存商品信息
	 * @Description:  
	 * @author: 李赛
	 * @param file
	 * @param req
	 * @return
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	@RequestMapping("addCarHandler")
	public String addCar(@RequestParam(value ="imgFile") MultipartFile file,HttpServletRequest req) throws IllegalStateException, IOException{
		String newName = null;
		if(file.getSize()>0){
			String oldName = file.getOriginalFilename();
			newName = UUID.randomUUID().toString().replace("-", "")+oldName.substring(oldName.lastIndexOf("."));
	        //根据eclipse配置Reploy路径，想要获取服务器（容器）的绝对路径
			File savedFile = new File( req.getSession().getServletContext().getRealPath("/") + "/WEB-INF/static/images/cars/" + newName  );  
			//File savedFile = new File("F:/upload/" + newName  );  
			System.out.println();
			System.out.println(savedFile);
	        file.transferTo(savedFile);  //转存文件  
		}
        //商品名称
		String toyname = req.getParameter("toyname");
		//价格
		double price = Double.parseDouble(req.getParameter("price"));
		//类型
		Integer toytype=  Integer.valueOf(req.getParameter("toytype"));
		//是否热搜
//		Integer isdown=   Integer.valueOf(req.getParameter("isdown"));
		//总量
		Integer totalnum = Integer.valueOf(req.getParameter("totalnum"));
		String img = newName;
		String description = req.getParameter("description");
		Toyinfo toyinfo = new Toyinfo();
		toyinfo.setToyname(toyname);
		toyinfo.setToytype(toytype);
		//toyinfo.setIsdown(isdown); 
		toyinfo.setPrice(price);
		toyinfo.setTotalnum(totalnum);
		toyinfo.setImg(img);
		toyinfo.setBz2(description);
		int result = toyInfoService.insertSelective(toyinfo);
		if(result>0){
			return "returnadminListOrder";
		}
		return "error";
	}
	
	
	
	
	/**
	 * 查询订单列表
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("selectOrderList")
	public String selectOrderList(HttpServletRequest request){
		SimpleDateFormat fo = new SimpleDateFormat("yyyy-MM-dd");
		
		String noid = request.getParameter("noid")==""?null:request.getParameter("noid");
		String username = request.getParameter("username")==""?null:request.getParameter("username");
		Orderinfo orderInfo = new Orderinfo();
		orderInfo.setToynoid(noid);
		orderInfo.setUsername(username);
		//查询所有的订单
		List<Orderinfo> orderList = orderInfoService.selectOrderInfo(orderInfo);
		for (Orderinfo orderinfo : orderList) {
			orderinfo.setBz3(fo.format(orderinfo.getBuydate()));
		}
		request.setAttribute("orderList", orderList);
		return "listOrder";
	}
	
	
	/**
	 * 删除订单
	 * @Description:  
	 * @author: 李赛
	 * @param req
	 * @return
	 */
	@RequestMapping("deleteOrder")
	public String deleteOrder(HttpServletRequest req){
		int orderid = Integer.parseInt(req.getParameter("orderid"));
		
		int result = orderInfoService.deleteByPrimaryKey(orderid);
		if(result>0){
			return "returnListOreder";
		}
		return "error";
	}
	
	
	/**
	 * 查询订单
	 * @Description:  
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("searchOrder")
	public String findCust() {
		return "searchOrder";
	}
	
	
	
	/**
	 * 订单查询用户
	 * @Description:  
	 * @author: 李赛
	 * @param req
	 * @return
	 */
	@RequestMapping("findOrder")
	@ResponseBody
	public String findCusts(HttpServletRequest req) {
		SimpleDateFormat fo = new SimpleDateFormat("yyyy-MM-dd");
		String name = req.getParameter("name");
		String noid = req.getParameter("noid");
		Orderinfo order = new Orderinfo();
		//用户名
		if(!StringUtils.isEmpty(name)){
			order.setUsername(name);
		}
		//订单编号
		if(!StringUtils.isEmpty(noid)){
			order.setToynoid(noid);
		}
		//查询
		List<Orderinfo> list = orderInfoService.selectOrderInfo(order);
		for (Orderinfo orderinfo : list) {
			orderinfo.setBz4(fo.format(orderinfo.getBuydate()));
			if(orderinfo.getBz2()==1){
				orderinfo.setBz3("精品手办");
			}else if(orderinfo.getBz2()==2){
				orderinfo.setBz3("布偶抱枕");
			}else if(orderinfo.getBz2()==3){
				orderinfo.setBz3("传统古风");
			}else if(orderinfo.getBz2()==4){
				orderinfo.setBz3("缤纷服饰");
			}else if(orderinfo.getBz2()==5){
				orderinfo.setBz3("创意益智");
			}
			
			if(orderinfo.getIsevaluate()==1){
				orderinfo.setEvaluate("是");
			}else if(orderinfo.getIsevaluate()==2){
				orderinfo.setEvaluate("否");
			}
		}
		
		// 从业务层拿到数据
		// 将数据转换成json
		Gson gson = new Gson();
		// 使用gson将集合转换成json串
		String json = gson.toJson(list);
		return json;
	}
	
	/**
	 * 下架商品
	 * @Description:  
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("downToyid")
	public String downToyid(HttpServletRequest req) {
		//获取商品id
		String isdown = req.getParameter("isdown");
		//获取商品id
		String toyid = req.getParameter("toyid");
		Toyinfo toy = new Toyinfo();
		toy.setId(Integer.valueOf(toyid));
		toy.setIsdown(Integer.valueOf(isdown));
		toyInfoService.updateDown(toy);
		return "returnListToy";
	}
	
	
	/**
	 * 商品上主页
	 * @Description:  
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("updateToyTop")
	public String updateToyTop(HttpServletRequest req) {
		//获取商品id
		String istop = req.getParameter("istop");
		//获取商品id
		String toyid = req.getParameter("toyid");
		Toyinfo toy = new Toyinfo();
		toy.setId(Integer.valueOf(toyid));
		toy.setIstop(Integer.valueOf(istop));
		toyInfoService.updateIstop(toy);
		return "returnListToy";
	}
	
	/**
	 * 删除商品
	 * @Description:  
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("deleteToy")
	public String deleteToy(HttpServletRequest req) {
		//获取商品id
		String toyid = req.getParameter("toyid");
		toyInfoService.deleteByPrimaryKey(Integer.valueOf(toyid));
		return "returnListToy";
	}
	
	
	
	/**
	 * 修改商品
	 * @Description:  
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("updateToy")
	public String updateToy(HttpServletRequest req) {
		//获取商品id
		String toyid = req.getParameter("toyid");
		Toyinfo toyInfo = toyInfoService.selectByPrimaryKey(Integer.valueOf(toyid));
		req.setAttribute("toyInfo", toyInfo);
		return "updateToy";
	}
	
	
	
	/**
	 * 修改商品信息
	 * @Description:  
	 * @author: 李赛
	 * @param file
	 * @param req
	 * @return
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	@RequestMapping("updateToyInfo")
	public String updateToyInfo(@RequestParam(value ="imgFile") MultipartFile file,HttpServletRequest req) throws IllegalStateException, IOException{
		String newName = null;
		if(file.getSize()>0){
			String oldName = file.getOriginalFilename();
			newName = UUID.randomUUID().toString().replace("-", "")+oldName.substring(oldName.lastIndexOf("."));
	        //根据eclipse配置Reploy路径，想要获取服务器（容器）的绝对路径
			File savedFile = new File( req.getSession().getServletContext().getRealPath("/") + "/WEB-INF/static/images/cars/" + newName  );  
			//File savedFile = new File("E:/images/" + newName  );  
			System.out.println();
			System.out.println(savedFile);
	        file.transferTo(savedFile);  //转存文件  
		}
		//id
		Integer toyid = Integer.valueOf(req.getParameter("toyid"));
        //商品名称
		String toyname = req.getParameter("toyname");
		//价格
		double price = Double.parseDouble(req.getParameter("price"));
		//类型
		Integer toytype=  Integer.valueOf(req.getParameter("toytype"));
		//是否热搜
		//Integer istop=   Integer.valueOf(req.getParameter("istop"));
		//总量
		Integer totalnum = Integer.valueOf(req.getParameter("totalnum"));
		String img = newName;
		String description = req.getParameter("description");
		
		Toyinfo toyinfo = toyInfoService.selectByPrimaryKey(toyid);
		toyinfo.setId(toyid);
		toyinfo.setIstop(2);
		toyinfo.setIsdown(2);
		if(!StringUtils.isEmpty(toyname)){
			toyinfo.setToyname(toyname);
		}
		if(!org.springframework.util.StringUtils.isEmpty(toytype)){
			toyinfo.setToytype(toytype);
		}	
		/*if(org.springframework.util.StringUtils.isEmpty(istop)){
			toyinfo.setIsdown(istop); 
		}*/	
		if(!org.springframework.util.StringUtils.isEmpty(price)){
			toyinfo.setPrice(price);
		}
		if(!org.springframework.util.StringUtils.isEmpty(totalnum)){
			toyinfo.setTotalnum(totalnum);
		}	
		if(!org.springframework.util.StringUtils.isEmpty(img)){
			toyinfo.setImg(img);
		}	
		if(!org.springframework.util.StringUtils.isEmpty(description)){
			toyinfo.setBz2(description);
		}
		int result = toyInfoService.updateByPrimaryKeySelective(toyinfo);
		if(result>0){
			return "returnListToy";
		}
		return "error";
	}
	
	
	
	
	
	
	/**
	 * 查询订单列表
	 * @Description:  
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("selectShipList")
	public String selectShipList(HttpServletRequest request){
		SimpleDateFormat fo = new SimpleDateFormat("yyyy-MM-dd");
		//查询所有的订单
		List<Orderinfo> orderList = orderInfoService.selectIsShipList();
		for (Orderinfo orderinfo : orderList) {
			orderinfo.setBz3(fo.format(orderinfo.getBuydate()));
			
		}
		request.setAttribute("orderList", orderList);
		return "listShipOrder";
	}
	
	
	
	/**
	 * 商品发货
	 * @Description:  
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("shipOrder")
	public String shipOrder(HttpServletRequest req) {
		//获取商品id
		String orderid = req.getParameter("orderid");
		//获取状态类型
		String type = req.getParameter("type");
		Orderinfo oderInfo = new Orderinfo();
		oderInfo.setId(Integer.valueOf(orderid));
		oderInfo.setBz1(Integer.valueOf(type));
		orderInfoService.updateShip(oderInfo);
		
		return "returnShipOreder";
	}
	
	
	
	/**
	 * 商品收货
	 * @Description:  
	 * @author: 李赛
	 * @return
	 */
	@RequestMapping("receShop")
	public String receShop(HttpServletRequest req) {
		//获取商品id
		String orderid = req.getParameter("orderid");
		//获取状态类型
		String type = req.getParameter("type");
		Orderinfo oderInfo = new Orderinfo();
		oderInfo.setId(Integer.valueOf(orderid));
		oderInfo.setBz1(Integer.valueOf(type));
		orderInfoService.updateShip(oderInfo);
		
		return "returnOrederList";
	}
}
