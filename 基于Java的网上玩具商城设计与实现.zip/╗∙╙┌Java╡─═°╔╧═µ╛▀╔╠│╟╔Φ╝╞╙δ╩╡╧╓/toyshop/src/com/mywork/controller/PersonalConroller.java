package com.mywork.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.mywork.pojo.Orderinfo;
import com.mywork.pojo.User;
import com.mywork.service.OrderInfoService;
import com.mywork.service.ToyInfoService;
import com.mywork.service.UserService;

/**
 * 个人中心controller
 * @Description:  
 * @author: 李赛
 */
@Controller
public class PersonalConroller {
	@Autowired
	private ToyInfoService toyInfoService;
	@Autowired
	UserService userService;
	@Autowired
	private OrderInfoService orderInfoService;
	/**
	 * @Description: 个人信息首页 
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("mygxin")
	public String mygxin(HttpServletRequest request) {
		// 通过session中的用户去拿到user的id
		User user = (User) request.getSession().getAttribute("currentUser");
		if(user==null){
			return "login";
		}
		
		user = userService.findUserById(user.getUserid());
		request.setAttribute("user",user);
		Orderinfo record = new Orderinfo();
		//当前用户
		record.setUserid(user.getUserid());
		//未评价
		record.setIsevaluate(2);
		record.setBz1(4);
		//查询当前用户下的所有订单
		List<Orderinfo> notorderList =  orderInfoService.selectByStatus(record);
		//待收货订单
		record.setBz1(3);
		List<Orderinfo> lreceorderList =  orderInfoService.selectByStatus(record);
		record.setBz1(1);
		//查询当前用户下的所有订单
		List<Orderinfo> receorderList =  orderInfoService.selectByStatus(record);
		
		record.setBz1(5);
		//查询当前用户下的所有订单
		List<Orderinfo> nopayList =  orderInfoService.selectByStatus(record);
		request.setAttribute("nopayList",nopayList.size());
		request.setAttribute("notevaluate",notorderList.size());
		request.setAttribute("receorderList",receorderList.size());
		request.setAttribute("lreceorderList",lreceorderList.size());
		return "mygxin";
	}
	
	/**
	 * @Description: 个人信息详情页 
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("mygrxx")
	public String mygrxx(HttpServletRequest request) {
		// 通过session中的用户去拿到user的id
		User user = (User) request.getSession().getAttribute("currentUser");
		user = userService.findUserById(user.getUserid());
		request.setAttribute("user",user);
		// 通过request存储menus.
		return "mygrxx";
	}
	
	/**
	 * @Description: 保存个人信息
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("saveUser")
	public String saveUser(User user,HttpServletRequest request){
		userService.updateUser(user);
		return "returnMygxin";
	}
	
	/**
	 * @Description: 支付接口跳转修改个人信息
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("saveUserPay")
	public String saveUserPay(User user,HttpServletRequest request){
		//商品id
		int toyid = Integer.valueOf(request.getParameter("toyid"));
		//商品订单
		int orderid = Integer.valueOf(request.getParameter("orderid"));
		//购买数量
		int buynum = Integer.valueOf(request.getParameter("buynum"));
		//支付方式
		int paytype = Integer.valueOf(request.getParameter("paytype"));
		request.setAttribute("paytype", paytype);
		request.setAttribute("orderid", orderid);
		request.setAttribute("toyid", toyid);
		request.setAttribute("buynum", buynum);
		userService.updateUser(user);
		
		return "returnOreder";
	}
	
	/**
	 * @Description: 支付接口跳转修改个人信息
	 * @author: 李赛
	 * @param request
	 * @return
	 */
	@RequestMapping("saveUserPayCart")
	public String saveUserPayCart(User user,HttpServletRequest request){
		//商品订单
		String orderid = request.getParameter("orderid") ;
		request.setAttribute("orderid", orderid);
		userService.updateUser(user);
		return "returnOrederCart";
	}
	
	
	/**
	 * @Description: 保存头像
	 * @author: 李赛
	 * @param request
	 * @return
	 * @throws IOException 
	 * @throws IllegalStateException 
	 */
	@RequestMapping("saveUserImg")
	public String saveUserImg(@RequestParam(value ="realname") MultipartFile file,HttpServletRequest request) throws IllegalStateException, IOException {
		String newName = null;
		if(file.getSize()>0){
			String oldName = file.getOriginalFilename();
			newName = UUID.randomUUID().toString().replace("-", "")+oldName.substring(oldName.lastIndexOf("."));
	        //根据eclipse配置Reploy路径，想要获取服务器（容器）的绝对路径
			File savedFile = new File( request.getSession().getServletContext().getRealPath("/") + "/WEB-INF/static/images/cars/" + newName  );  
			//File savedFile = new File("E:/images/" + newName  );  
			System.out.println(savedFile);
	        file.transferTo(savedFile);  //转存文件  
		}
		String userid = request.getParameter("userid");
		User user = new User();
		user.setUserid(Integer.valueOf(userid));
		user.setRealname(newName);
		userService.updateUser(user);
		return "returnMygxin";
	}
	
}
