package com.mywork.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.mywork.config.AlipayConfig;
import com.mywork.pojo.Orderinfo;
import com.mywork.pojo.User;
import com.mywork.service.OrderInfoService;
import com.mywork.service.ToyInfoService;
import com.mywork.service.UserService;

/**
 * 支付controller
 * @Description:  
 * @author: 李赛
 */
@Controller
public class PayController {

	@Autowired
	private OrderInfoService orderInfoService;

	@Autowired
	private ToyInfoService toyInfoService;
	@Autowired
	UserService userService;
	/**
	 * @Description: 支付功能 
	 * @author: 李赛
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	/*@RequestMapping("/pay")
	public void payController(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //获得初始化的AlipayClient
        AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.APP_ID, AlipayConfig.APP_PRIVATE_KEY, "json", AlipayConfig.CHARSET, AlipayConfig.ALIPAY_PUBLIC_KEY, AlipayConfig.sign_type);

        //设置请求参数
        AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();
        alipayRequest.setReturnUrl(AlipayConfig.return_url);
        alipayRequest.setNotifyUrl(AlipayConfig.notify_url);

        //商户订单号，商户网站订单系统中唯一订单号，必填
        long currtime = System.currentTimeMillis();
        String out_trade_no = new String(String.valueOf(currtime).getBytes("ISO-8859-1"),"UTF-8");
        //付款金额，必填
        String total_amount = new String(request.getParameter("WIDtotal_amount").getBytes("ISO-8859-1"),"UTF-8");
        //订单名称，必填
        String subject  = null;
        int sub = Integer.valueOf(request.getParameter("WIDsubject"));
        if(sub==1){
        	subject = "精品手办";
        }else if(sub==2){
        	subject = "布偶抱枕";
        }else if(sub==3){
        	subject = "传统古风";
        }else if(sub==4){
        	subject = "缤纷服饰";
        }else if(sub==5){
        	subject = "创意益智";
        } 
        //商品id
        String toyid = new String(request.getParameter("toyid").getBytes("ISO-8859-1"),"UTF-8");
        //商品名称
        String toyname = request.getParameter("toyname"); 
        //购买数量
        String buynum = new String(request.getParameter("buynum").getBytes("ISO-8859-1"),"UTF-8");
        //图片
        String img = request.getParameter("img"); 
        //单价
        String price = new String(request.getParameter("price").getBytes("ISO-8859-1"),"UTF-8");
        //支付方式
        String paytype = new String(request.getParameter("paytype").getBytes("ISO-8859-1"),"UTF-8");
        //订单id
        String orderid = new String(request.getParameter("orderid").getBytes("ISO-8859-1"),"UTF-8");
        //商品描述，可空
        String body = "";
       
       
        
        //对订单表新增数据
        Orderinfo orderInfo = new Orderinfo();
        //订单编号
        orderInfo.setToynoid(out_trade_no);
        //用户id
        User user = (User) request.getSession().getAttribute("currentUser");
        orderInfo.setUserid(user.getUserid());
        //用户名称
        orderInfo.setUsername(user.getUsername());
        //商品id
        orderInfo.setToyid(Integer.valueOf(toyid));
        //商品名称
        orderInfo.setToyname(toyname);
        //购买数量
        orderInfo.setBuynum(Integer.valueOf(buynum));
        //总金额
        orderInfo.setTotalprice(Double.valueOf(total_amount));
        //日期
        Date date = new Date();
        orderInfo.setBuydate(date);
        //是否评价2
        orderInfo.setIsevaluate(2);
        //图片
        orderInfo.setImg(img);
        //单价
        orderInfo.setPrice(Double.valueOf(price));
        //支付
        Integer paytypeint = Integer.valueOf(paytype);
        orderInfo.setBz1(1);
        //类型
        orderInfo.setBz2(sub);
        //新增订单
        int id = 0;
        if(paytypeint==1&&Integer.valueOf(orderid)==0){
        	id = orderInfoService.insertSelective(orderInfo);
        }else{
        	orderInfo.setId(Integer.valueOf(orderid));
        	orderInfoService.updateByPrimaryKeySelective(orderInfo);
        }
        //更新商品卖出数量
        Toyinfo toy = new Toyinfo();
        //商品id
        toy.setId(Integer.valueOf(toyid));
        //卖出数量
        toy.setNum(Integer.valueOf(buynum));
        toyInfoService.updateNum(toy);
        
        subject = id+"";
        alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\","
                + "\"total_amount\":\""+ total_amount +"\","
                + "\"subject\":\""+ subject +"\","
                + "\"body\":\""+ body +"\","
                + "\"toyid\":\""+ toyid +"\","
                + "\"toyname\":\""+ toyname +"\","
                + "\"buynum\":\""+ buynum +"\","
                + "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
        
        //请求
        String form="";
        try {
            form = alipayClient.pageExecute(alipayRequest).getBody(); //调用SDK生成表单
        } catch (AlipayApiException e) {
            e.printStackTrace();
        }
        response.setContentType("text/html;charset=" + AlipayConfig.CHARSET);
        response.getWriter().write(form);//直接将完整的表单html输出到页面
        response.getWriter().flush();
        response.getWriter().close();
	 }*/
	
	
	
	@RequestMapping("/pay")
	public void payController(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //获得初始化的AlipayClient
        AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.APP_ID, AlipayConfig.APP_PRIVATE_KEY, "json", AlipayConfig.CHARSET, AlipayConfig.ALIPAY_PUBLIC_KEY, AlipayConfig.sign_type);

        //设置请求参数
        AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();
        alipayRequest.setReturnUrl(AlipayConfig.return_url);
        alipayRequest.setNotifyUrl(AlipayConfig.notify_url);

       
        //付款金额，必填
        String total_amount = new String(request.getParameter("WIDtotal_amount").getBytes("ISO-8859-1"),"UTF-8");
        //订单名称，必填
        String subject  = null;
        int sub = Integer.valueOf(request.getParameter("WIDsubject"));
        if(sub==1){
        	subject = "精品手办";
        }else if(sub==2){
        	subject = "布偶抱枕";
        }else if(sub==3){
        	subject = "传统古风";
        }else if(sub==4){
        	subject = "缤纷服饰";
        }else if(sub==5){
        	subject = "创意益智";
        } 
        //商品id
        String toyid = new String(request.getParameter("toyid").getBytes("ISO-8859-1"),"UTF-8");
        //商品名称
        String toyname = request.getParameter("toyname"); 
        //购买数量
        String buynum = new String(request.getParameter("buynum").getBytes("ISO-8859-1"),"UTF-8");
        //图片
        String img = request.getParameter("img"); 
        //单价
        String price = new String(request.getParameter("price").getBytes("ISO-8859-1"),"UTF-8");
        //支付方式
        String paytype = new String(request.getParameter("paytype").getBytes("ISO-8859-1"),"UTF-8");
        //订单id
        String orderid = new String(request.getParameter("orderid").getBytes("ISO-8859-1"),"UTF-8");
        //商品描述，可空
        String body = "";
        
        //对订单表新增数据
        Orderinfo orderInfo = new Orderinfo();
        //订单编号
        //orderInfo.setToynoid(out_trade_no);
        //用户id
        User user = (User) request.getSession().getAttribute("currentUser");
        // 通过session中的用户去拿到user的id
     	user = userService.findUserById(user.getUserid());
        orderInfo.setUserid(user.getUserid());
        //用户名称
        orderInfo.setUsername(user.getUsername());
        //商品id
        orderInfo.setToyid(Integer.valueOf(toyid));
        //商品名称
        orderInfo.setToyname(toyname);
        //购买数量
        orderInfo.setBuynum(Integer.valueOf(buynum));
        //总金额
        orderInfo.setTotalprice(Double.valueOf(total_amount));
        //日期
        Date date = new Date();
        orderInfo.setBuydate(date);
        //是否评价2
        orderInfo.setIsevaluate(2);
        //图片
        orderInfo.setImg(img);
        //单价
        orderInfo.setPrice(Double.valueOf(price));
        //支付
        Integer paytypeint = Integer.valueOf(paytype);
        //待支付
        orderInfo.setBz1(5);
        //类型
        orderInfo.setBz2(sub);
        //收货人姓名
        orderInfo.setBz3(user.getPosition());
		//收货人电话
        orderInfo.setBz4(user.getIdentity());
		//收货地址
        orderInfo.setBz5(user.getAddress());
        
        //新增订单
        int id = 0;
        if(paytypeint==1&&Integer.valueOf(orderid)==0){
        	id = orderInfoService.insertSelective(orderInfo);
        }else{
        	id = Integer.valueOf(orderid);
        	orderInfo.setId(Integer.valueOf(orderid));
        	orderInfoService.updateByPrimaryKeySelective(orderInfo);
        }
        
        
        
        
        
        //商户订单号，商户网站订单系统中唯一订单号，必填
        long currtime = System.currentTimeMillis();
        String out_trade_no = new String(String.valueOf(currtime+"|"+id+",").getBytes("ISO-8859-1"),"UTF-8");        
        alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\","
                + "\"total_amount\":\""+ total_amount +"\","
                + "\"subject\":\""+ subject +"\","
                + "\"body\":\""+ body +"\","
                + "\"toyid\":\""+ toyid +"\","
                + "\"toyname\":\""+ toyname +"\","
                + "\"buynum\":\""+ buynum +"\","
                + "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
        
        
        //请求
        String form="";
        try {
            form = alipayClient.pageExecute(alipayRequest).getBody(); //调用SDK生成表单
        } catch (AlipayApiException e) {
            e.printStackTrace();
        }
        response.setContentType("text/html;charset=" + AlipayConfig.CHARSET);
        response.getWriter().write(form);//直接将完整的表单html输出到页面
        response.getWriter().flush();
        response.getWriter().close();
	 }
	
	
	
	/**
	 * @Description: 支付功能 
	 * @author: 李赛
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/payCart")
	public void payCart(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //获得初始化的AlipayClient
        AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.APP_ID, AlipayConfig.APP_PRIVATE_KEY, "json", AlipayConfig.CHARSET, AlipayConfig.ALIPAY_PUBLIC_KEY, AlipayConfig.sign_type);

        //设置请求参数
        AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();
        alipayRequest.setReturnUrl(AlipayConfig.return_url);
        alipayRequest.setNotifyUrl(AlipayConfig.notify_url);

             //付款金额，必填
        String total_amount = new String(request.getParameter("WIDtotal_amount").getBytes("ISO-8859-1"),"UTF-8");
        //订单名称，必填
        String WIDsubject = "网上玩具商城";
        //订单id
        String orderids = request.getParameter("orderid");
        //商品描述，可空
        String body = "";
       
        //商户订单号，商户网站订单系统中唯一订单号，必填
        long currtime = System.currentTimeMillis();
        String out_trade_no = new String(String.valueOf(currtime+"|"+orderids).getBytes("ISO-8859-1"),"UTF-8");

        //用户id
        User user = (User) request.getSession().getAttribute("currentUser");
        // 通过session中的用户去拿到user的id
     	user = userService.findUserById(user.getUserid());
        
        alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\","
                + "\"total_amount\":\""+ total_amount +"\","
                + "\"subject\":\""+ WIDsubject +"\","
                + "\"body\":\""+ body +"\","
                + "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
        
        String[] orderid = orderids.substring(0, orderids.length()-1).split(",");
        for (String string : orderid) {
        	
        	Orderinfo order = orderInfoService.selectByPrimaryKey(Integer.valueOf(string));
        	//更新商品卖出数量
          /*  Toyinfo toy = new Toyinfo();
            //商品id
            toy.setId(order.getToyid());
            //卖出数量
            toy.setNum(order.getBuynum());
            toyInfoService.updateNum(toy);*/
            
        	 //对订单表新增数据
            Orderinfo orderInfo = new Orderinfo();
            //订单编号
            orderInfo.setToynoid(order.getToynoid());
            orderInfo.setUserid(order.getUserid());
            //orderInfo.setToynoid(String.valueOf(currtime));
            //用户名称
            orderInfo.setUsername(order.getUsername());
            //商品id
            orderInfo.setToyid(order.getToyid());
            //商品名称
            orderInfo.setToyname(order.getToyname());
            //购买数量
            orderInfo.setBuynum(order.getBuynum());
            //总金额
            orderInfo.setTotalprice(order.getTotalprice());
            //日期
            Date date = new Date();
            orderInfo.setBuydate(date);
            //是否评价2
            orderInfo.setIsevaluate(2);
            //图片
            orderInfo.setImg(order.getImg());
            //单价
            orderInfo.setPrice(order.getPrice());
            //是否评价2
            orderInfo.setIsevaluate(2);
            //支付
            orderInfo.setBz1(5);
            //收货人姓名
            orderInfo.setBz3(user.getPosition());
    		//收货人电话
            orderInfo.setBz4(user.getIdentity());
    		//收货地址
            orderInfo.setBz5(user.getAddress());
            
            
            //新增订单
            orderInfo.setId(Integer.valueOf(string));
            orderInfoService.updateByPrimaryKeySelective(orderInfo);
        	
		}
        
        //请求
        String form="";
        try {
            form = alipayClient.pageExecute(alipayRequest).getBody(); //调用SDK生成表单
        } catch (AlipayApiException e) {
            e.printStackTrace();
        }
        response.setContentType("text/html;charset=" + AlipayConfig.CHARSET);
        response.getWriter().write(form);//直接将完整的表单html输出到页面
        response.getWriter().flush();
        response.getWriter().close();
	 }
	
}
